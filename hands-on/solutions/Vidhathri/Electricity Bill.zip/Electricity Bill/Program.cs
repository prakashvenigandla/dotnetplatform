﻿using System;


namespace ElectricityBill
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            do
            {

                int eunits;
                double bill = 0;
                double tbill;
               
                Console.WriteLine("Enter the number of units:");
                eunits = Convert.ToInt32(Console.ReadLine());
                if (eunits > 0 && eunits <= 100)
                {
                    bill += eunits * 5;
                }
                else if (eunits >= 101 && eunits <= 200)
                    bill = 500 + (eunits - 100) * 7;
                else if (eunits >= 201 && eunits <= 300)
                    bill = 1200 + (eunits - 200) * 10;
                else
                    Console.WriteLine("Enter a valid number");
                double gst;
                gst = 0.14 * bill;
                Console.WriteLine("The bill is:" + bill);
                Console.WriteLine("The gst is:" + gst);
                tbill = bill + gst;
                Console.WriteLine("The total electricity bill along with gst=" + tbill);
                Console.WriteLine("If u want to continue the process press yes other wise no");
                str = Console.ReadLine();

            } while (str == "y");



        }
    }
}