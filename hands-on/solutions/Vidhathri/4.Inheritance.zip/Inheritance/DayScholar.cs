﻿using System;

namespace Inheritance
{
    public class DayScholar : Student
    {
        //public string Conveyance;
        //public double TransportationCharges;
        public string Conveyance { get; set; }
        public double TransportationCharges { get; set; }
        public double TotalFee { get; set; }
       
        

        public DayScholar(string Name,string RollNum,string Address, double TuitionFee,
            string Conveyance, double TransportationCharges)
        {
            this.Name = Name;
            this.RollNum = RollNum;
            this.TuitionFee = TuitionFee;
            this.Address = Address;
            this.Conveyance = Conveyance;
            this.TransportationCharges = TransportationCharges;
            
            

        }
        public override void display()
        {
            Console.WriteLine("\n-------:: Student Details ::--------");
            Console.WriteLine("Name of the student is:" + Name);
            Console.WriteLine("Roll Number of student is:" + RollNum);
            Console.WriteLine("The Tuition Fee is:" + TuitionFee);
            Console.WriteLine(" Address od the student:" + Address);
            Console.WriteLine("The Conveyance type of students is:"+ Conveyance);
            Console.WriteLine("The Transportation Charges are:{0}", TransportationCharges);
            Console.WriteLine("The total fee for a DayScholar along with transportation charges is:{0}",
               TransportationCharges + TuitionFee);

        }

    }
}
