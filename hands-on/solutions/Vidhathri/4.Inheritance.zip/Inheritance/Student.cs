﻿using System;

namespace Inheritance
{
    public class Student
    {
        public string Name { get; set; }
        public string RollNum { get; set; }
        public double TuitionFee { get; set; }
        public string Address { get; set; }
        /*public Student()
        {

        }

       public Student(string Name, string RollNum,double TuitionFee)
        {
            this.Name = Name;
            this.RollNum = RollNum;
            this.TuitionFee = TuitionFee;

        }*/
        public virtual void display()
        {
          
        }

    }
}
