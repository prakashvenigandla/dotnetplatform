﻿using System;


namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
           
            DayScholar d1 = new DayScholar("Vidhathri","17281A0579","12 Rajiv Colony",50000,"Bus", 15000);
            DayScholar d2 = new DayScholar("Sanju", "17281A0580","34 Gandhi Nagar",35000,"Bus", 150000);
            DayScholar d3 = new DayScholar("Prachi", "17281A0581","34 Baker Colony", 35000, "Bus", 200000);

            Hosteller h1 = new Hosteller("Gunav", "17281A0573", "12Ganesh Nagar",20000,"Wing-A", 15000, "Swimming");
            Hosteller h2 = new Hosteller("Karan", "17281A0575", "13Banjara Bills", 40000, "Wing-B", 20000, "Table Tennis");
            d1.display();
            d2.display();
            d3.display();
            h1.display();
            h2.display();






        }
    }
}
