﻿using System;

namespace Inheritance
{
    public class Hosteller : Student
    {
        public string HostelWing;
        public double HostelFee;
        public string EvngActivity;
      
        public Hosteller(string Name, string RollNum,  string Address, double TuitionFee,
            string HostelWing, double HostelFee, string EvngActivity)
        {
            this.Name = Name;
            this.RollNum = RollNum;
            this.TuitionFee = TuitionFee;
            this.Address = Address;
            this.HostelWing = HostelWing;
            this.HostelFee = HostelFee;
            this.EvngActivity = EvngActivity;

        }
        public new void display()
        {
            Console.WriteLine("\n-------:: Student Details ::--------\n");
            Console.WriteLine("Name of the student is:" + Name);
            Console.WriteLine("Roll Number of student is:" + RollNum);
            Console.WriteLine("The Tuition Fee is:" + TuitionFee);
            Console.WriteLine(" Address od the student:" + Address);
            Console.WriteLine("The Hostel Wing of students is:{0}", HostelWing);
            Console.WriteLine("The Hostel Charges are:{0}", HostelFee);
            Console.WriteLine("The Evening Activity is:"+ EvngActivity);
            Console.WriteLine("The total fee for a DayScholarHosteller along with Hostel Fees  is{0}",
               HostelFee + TuitionFee);

        }

    }
}
