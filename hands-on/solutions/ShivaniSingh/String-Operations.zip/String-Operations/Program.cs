﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String_Operations
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "Shivani";
            string str2 = "Singh";
            Console.WriteLine(str1.Length);
            Console.WriteLine(string.Concat(str1, str2));
            Console.WriteLine(string.Compare(str1, str2));
            Console.WriteLine(string.Equals(str1, str2));
            char[] a = str2.ToCharArray();
            Console.WriteLine(a);
            Console.WriteLine(str1.ToUpper());
            Console.WriteLine(str2.Reverse());

        }
    }
}
