﻿using System;


namespace IheritanceConcept
{
    class Program
    {
       public static void Main(string[] args)
       {
            Student s; Hosteler h; Dayscholar d;
            s = new Student("Shivi", 22, "Engineering");
            s.Details();
            h = new Hosteler(3, 2000);
            h.Details();
            s = new Student("Harshita", 21, "BBA");
            d = new Dayscholar(3000, 1500);
            d.Details();
       }
    }
}
