﻿using System;

namespace IheritanceConcept
{
    class Student
    {
        public string name;
        public int age;
        public string course;
        public Student(string name,int age , string course)
        {
            this.name = name;
            this.age = age;
            this.course = course;
        }
        public Student()
        {

        }
        public virtual void Details()
        {
            Console.WriteLine("Details of student is, Name-" + name + " Age-" + age + " Course" + course);
        }
    }
}
