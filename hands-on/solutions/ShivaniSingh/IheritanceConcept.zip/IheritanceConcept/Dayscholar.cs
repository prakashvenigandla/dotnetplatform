﻿using System;

namespace IheritanceConcept
{
    class Dayscholar:Student
    {
        int transfee, cancharge;
        public Dayscholar():base()
        {

        }
        public Dayscholar(int transfee,int cancharge) : base()
        {
            this.transfee = transfee;
            this.cancharge = cancharge;
        }
        public override void Details()
        {
            Console.WriteLine("Transport charges- {0}", transfee);
            Console.WriteLine("Canteen Charges-{0}", cancharge);
        }

    }
}
