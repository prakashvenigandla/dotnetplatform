﻿using System;


namespace IheritanceConcept
{
    class Hosteler:Student
    {
        int rs, messfee;
        public Hosteler():base()
        {

        }

        public  Hosteler(int rs, int messfee):base()
        {
            this.rs = rs;
            this.messfee = messfee;
        }
        public override void Details()
        {
            Console.WriteLine("Room sharing-{0}", rs);
            Console.WriteLine("Mess Fee-{0}", messfee);
        }
    }
}
