﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Built_In_Exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j, result = 0;
            Console.WriteLine("Enter No. First:");
            i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter No. Second: ");
            j = Convert.ToInt32(Console.ReadLine());
            try
            {
                result = i / j;
            }
            catch (Exception a)
            {
                Console.WriteLine(a.Message);
            }
            Console.WriteLine(result);
            try
            {
                int[] myNum = { 1, 2, 3 };
                Console.WriteLine(myNum[10]);
            }
            catch (Exception k)
            {
                Console.WriteLine(k.Message);
            }
            try
            {
                string s1 = null;
                Console.WriteLine("calculate".IndexOf(s1));
            }
            catch (Exception p)
            {
                Console.WriteLine(p.Message);
            }
            try
            {
                string s2 = "welcomeall";
                Console.WriteLine(s2[15]);
            }
            catch (IndexOutOfRangeException dbe)
            {
                Console.WriteLine(dbe.Message);
            }
        }
    }
}
