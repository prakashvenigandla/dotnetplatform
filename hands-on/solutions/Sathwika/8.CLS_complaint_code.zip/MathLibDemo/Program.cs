﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibNew;
using ClassLibrary1;
namespace MathLibClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj1 = new Class1();
            int c;
            c=obj1.Add1(10, 20);
            Console.WriteLine(c);
            Class2 obj2 = new Class2();
            obj2.Add2(1, 2);
            Console.ReadLine();
        }
    }
}
