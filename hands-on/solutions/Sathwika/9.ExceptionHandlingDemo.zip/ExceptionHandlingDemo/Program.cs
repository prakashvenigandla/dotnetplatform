﻿using System;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int res=0;
            Console.WriteLine("Enter a no");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter another no");
            b = Convert.ToInt32(Console.ReadLine());
            try
            {
                res = a / b;
            }
            catch(DivideByZeroException dbe)
            {
                Console.WriteLine(dbe.Message);
            }
            Console.WriteLine($"res: {res}");
            int[] x = new int[5];
            try
            {
                x[res]=res;
            }
            catch(IndexOutOfRangeException ire)
            {
                Console.WriteLine(ire.Message);
            }
            Console.WriteLine("x[res]="+x[res]);
            int x1 = 0, x2 = 0,x3=0;
            try
            {
                Console.WriteLine("Enter a number");
                x1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter another number");
                x2 = Convert.ToInt32(Console.ReadLine());
                Class1.Add(x1, x2);
               // Console.WriteLine();

            }
            catch (FormatException fe)
            {
                Console.WriteLine(fe.Message);
            }
            catch (ArgumentOutOfRangeException are)
            {
                Console.WriteLine(are.Message);
            }
            try
            {
                object val = 12;
                string s = (string)val;
            }
            catch(InvalidCastException ice)
            {
                Console.WriteLine(ice.Message);
            }
            Console.ReadLine();
            
        }
    }
}
