﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    static class Class1
    {
        public static int x;
        public static int y;

        public static void Add(int x,int y)
        {
            if(y>10)
            {
                throw new ArgumentOutOfRangeException();
            }

            Console.WriteLine("Sum is " + (x + y));
        }
    }
}
