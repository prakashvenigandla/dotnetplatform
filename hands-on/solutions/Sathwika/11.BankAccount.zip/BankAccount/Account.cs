﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccount
{
    class Account
    {
        public string accountNo;
        public string name;
        public string accType;
        private double balance;
        public string ifsc;
        public string branch;

        public Account(string accountNo,string name, string accType, double balance, string ifsc, string branch)
        {
            this.accountNo = accountNo;
            this.name = name;
            this.accType = accType;
            this.balance = balance;
            this.ifsc = ifsc;
            this.branch = branch;
        }

        public void TransferAmount(Account a1,double x)
        {
            if(x>this.balance)
            {
                throw new ArgumentOutOfRangeException();
            }
            this.balance = balance - x;
            a1.balance = balance + x;
            Console.WriteLine("Transaction Successful");

        }
        public void DisplayBalance()
        {
            Console.WriteLine("Current Balance is :"+this.balance);
        }

    }
}
