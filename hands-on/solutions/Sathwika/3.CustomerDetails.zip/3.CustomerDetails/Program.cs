﻿using System;

namespace CustomerDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer(12,"sathwika","dasusathwika@gmail.com","9876543210","Hanamkonda","Yes");
            c1.Display();
            Console.ReadLine();
        }
    }
}
