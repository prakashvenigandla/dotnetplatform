﻿using System;

namespace CustomerDetails
{
    class Customer
    {
        private int id;
        private string name;
        private string email;
        private string mobile;
        private string address;
        private string loyaltyMembership;

        //internal void display()
        //{
          //  throw new NotImplementedException();
        //}

        public int Id { get; set; }
        
        public string Mobile { get; set; }
        public string Name { get; set; }
        public string Email{ get; set; }
        public string Address { get; set; }
        public string LoyaltyMembership { get; set; }

        public Customer(int id,string name,string email,string mobile,string address,string loyaltyMembership)
        {
            Id = id;
            Name = name;
            Mobile = mobile;
            Email = email;
            Address = address;
            LoyaltyMembership = loyaltyMembership;
        }
        public void Display()
        {
            Console.WriteLine("Customer Details: ");
            Console.WriteLine("id :" + Id);
            Console.WriteLine("name: " + Name);
            Console.WriteLine("mobile: " + Mobile);
            Console.WriteLine("email: " + Email);
            Console.WriteLine("address: " + Address);
            Console.WriteLine("LoyaltyMembership: " + LoyaltyMembership);
        }
    }
}
