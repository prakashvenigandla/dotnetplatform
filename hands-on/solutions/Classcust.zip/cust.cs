﻿using System;
using OOPSConcept;
namespace OOPSConcepts
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer cust = new Customer(123, "Ram", "ram@gmail", 9121814088, "Canada", "Loyal");
            cust.Display();
        }
    }
}