﻿using System;

public class Customer
{
	public CustomerClass()
	{
		public int Id { get; set; };
		public string Name { get; set; };
		public string Email { get; set; };
		public int Mobile { get; set; };
		public string Address { get; set; };
		public string LoyaltyMembership { get; set; };

    Customer(int id, string name, string email, int mobile, string address, string loyalm) => Id = id => Name = name;
	public Display()
    {
        Console.WriteLine("Customer Details\n");
        Console.WriteLine("ID: {0}\n Name: {1}\n",Id,Name);
    }
}
}
