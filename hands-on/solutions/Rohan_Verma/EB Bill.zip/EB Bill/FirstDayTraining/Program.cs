﻿using System;

namespace FirstDayTraining
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Enter Units: ");
            int units = Convert.ToInt32(Console.ReadLine());
            double bill=0;
            if (units < 201)
            {
                bill = units * 3;
            }
            else if (units > 200 && units < 401)
            {
                bill += 200 * 3;
                units -= 200;
                bill += units * 4.50;
            }
            else if (units > 400 && units < 501)
            {
                bill += 200 * 3;
                units -= 200;
                bill += 100 * 4.50;
                units -= 200;
                bill += units * 6.50;
            }
            else if (units > 500)
            {
                bill += 200 * 3;
                units -= 200;
                bill += 100 * 4.50;
                units -= 200;
                bill += 100 * 6.50;
                units -= 100;
                bill += units * 7.50;
            }
            else
                Console.WriteLine("Wrong Input!");

            Console.WriteLine("\n The bill generated : " + bill);
            Console.WriteLine("\n GST : "+(0.14*bill));

            bill = 0.14 * bill + bill;

            Console.WriteLine("\n The bill generated including GSTIN : "+bill);
        }
    }
}
