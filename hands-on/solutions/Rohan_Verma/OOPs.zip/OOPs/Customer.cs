﻿using System;
namespace OOPs
{
    internal class Customer
    {
		public int Id;
		public string Name;
		public string Email;
		public int Mobile;
		public string Address;
		public string LoyaltyMembership;

		/*		public int Id { get; set; }
				public string Name { get; set; }
				public string Email { get; set; }
				public int Mobile { get; set; }
				public string Address { get; set; }
				public string LoyaltyMembership { get; set; }*/

		public Customer(int id, string name, string email, int mobile, string address, string loyalm)
		{
			this.Id = id;
			this.Name = name;
			this.Email = email;
			this.Mobile = mobile;
			this.Address = address;
			this.LoyaltyMembership = loyalm;
		}

		public void Display()
		{
			Console.WriteLine("Customer Details\n");
			Console.WriteLine("ID: {0}\nName: {1}\nEmail: {2}\nMobile: {3}\nAddress: {4}\nLoyaltyMembership: {5}", Id, Name, Email, Mobile, Address, LoyaltyMembership);
		}
	}
}