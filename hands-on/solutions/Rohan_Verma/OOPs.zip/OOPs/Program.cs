﻿using System;

namespace OOPs
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer newcustom = new Customer(1234, "Rohan Verma", "studentOne@gmail.com", 234234, "address", "yes");
            newcustom.Display();
        }
    }
}
