﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentRecords
{
    class DayScholar:Student
    {
        protected string TravelMethod { get; set; }
        public DayScholar(int id, string name, string programme, string email, bool hostler, string travelMethod, string houseadd)
        {
            Id = id;
            Name = name;
            Programme = programme;
            Email = email;
            Hostler = hostler;
            TravelMethod = travelMethod;
            HouseAddress= houseadd;
        }
        public override void Display()
        {
            Console.WriteLine("_____ :: Student Details :: _____");
            Console.WriteLine("ID: {0}\nName: {1}\nProgramme: {2}\nEmail: {3}\nHouse Address: {4}\nHostler: {5}\nTravel Method: {6}", Id, Name, Programme, Email, HouseAddress, Hostler, TravelMethod);
        }
    }
}
