﻿using System;

namespace StudentRecords
{
    class Program
    {
        static void Main(string[] args)
        {
            Hostler studentOne = new Hostler(1,"Rohan Verma","B.tech CSE","studentOne@g.com",true, "H Block", "Air Conditioned");
            DayScholar studentTwo = new DayScholar(2, "Priyanka Agrawal", "B.tech CSE", "studentTwo@g.com", false, "Metro", "West Delhi");
            studentOne.Display();
            studentTwo.Display();
        }
    }
}
