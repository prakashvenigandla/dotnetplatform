﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentRecords
{
    class Student
    {
        protected int Id { get; set; }
        protected string Name { get; set; }
        protected string Programme { get; set; }
        protected string Email { get; set; }
        protected bool Hostler { get; set; }
        protected string HouseAddress { get; set; }

        /*        public Student(int Id, string Name, string Programme, string Email, bool Hostler)
                {
                    this.Id = Id;
                    this.Name = Name;
                    this.Programme = Programme;
                    this.Email = Email;
                    this.Hostler = Hostler;
                }*/
        public virtual void Display()
        {
           
        }
        
    }
}
