﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudentRecords
{
    class Hostler:Student
    {
        public string HostelType { get; set; }
        protected string HostelName { get; set; }
        public Hostler(int id, string name, string programme, string email, bool hostler, string hostelName, string hostelType)
        {
            Id = id;
            Name = name;
            Programme = programme;
            Email = email;
            Hostler = hostler;
            HostelName = hostelName;
            HostelType = hostelType;
        }
        public override void Display()
        {
            Console.WriteLine("_____ :: Student Details :: _____");
            Console.WriteLine("ID: {0}\nName: {1}\nProgramme: {2}\nEmail: {3}\nHostler: {4}\nHostel Name: {5}\nHostel Type: {6}", Id, Name, Programme, Email, Hostler, HostelName, HostelType);
        }
    }
}
