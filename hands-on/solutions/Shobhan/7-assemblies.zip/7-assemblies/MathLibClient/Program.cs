﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLib;
using MathLibVB;


namespace MathLibClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1();
            Console.WriteLine("Library output"+obj.Add(2,3));

            Class2 obj2 = new Class2();
            Console.WriteLine("VB output:"+ obj.Add(7,3));
        }
    }
}
