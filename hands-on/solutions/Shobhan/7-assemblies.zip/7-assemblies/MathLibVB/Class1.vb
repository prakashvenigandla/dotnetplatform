﻿Public Class Class2
    Public Sub add(a As Integer, b As Integer)
        Console.WriteLine(a + b)
    End Sub
End Class
