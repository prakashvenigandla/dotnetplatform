﻿using System;

namespace Students
{
    class Program
    {
        static void Main(string[] args)
        {
            Students hostel = new Students("Shobhan Bhavesh",7244);
            hostel.Display();

            hostel =  new Hosteller("11AM","7PM",10000.50,10);
            hostel.Display();

            Students day = new Students("Shaurya Gupta", 7247);
            day.Display();

            day = new Dayscholar("9AM", "3PM", 10000.50,6);
            day.Display();

        }
    }
}
