﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeSalary
{
    class EmpSalary
    {
        public string Name { get; set; }
        public double salary { get; set; }
        public double hra;
        public double da;
        public double tax;
        public double gpay;
        public double nsalary;

        public EmpSalary(string name, double salary)
           {
            Name = name;
            this.salary = salary; // useful when there is starting with small letter of an auto implemented property
            hra = 0.15 * salary;
            da = 0.10 * salary;
            gpay = hra + da;
            tax = 0.08 * gpay;
            nsalary = gpay - tax;             
           }
        public EmpSalary()
        {
            this.salary = salary;
            hra = 0.15 * salary;
            da = 0.10 * salary;
            gpay = hra + da;
            tax = 0.08 * gpay;
            nsalary = gpay - tax;
        }
        public void Display()
           {
            Console.Write("Employee's Salary Informatioin and Breakdown \n");
            Console.WriteLine("Employee Name : "+Name+"\nBasic Salary : "+salary+" \nHRA : "+hra+"\nDA : "+da+"\nGross Pay : "+gpay+"\n Tax : "+tax+"\n Net Pay Salary : "+nsalary+"\n\n");
           }
    }
}
