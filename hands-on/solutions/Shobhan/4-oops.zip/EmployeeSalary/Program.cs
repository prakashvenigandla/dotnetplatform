﻿using System;

namespace EmployeeSalary
{
    class Program
    {
                
        static void Main(string[] args)
        {   //1st Constructor
            EmpSalary emp = new EmpSalary("Shobhan Bhavesh Sharma",30000.88);
            emp.Display();
            //2nd Constructor
            EmpSalary emp1 = new EmpSalary();
            emp1.Name = "Shaurya Gupta";
            emp1.salary = 33500.88;
            emp1.Display();
        }
    }
}
