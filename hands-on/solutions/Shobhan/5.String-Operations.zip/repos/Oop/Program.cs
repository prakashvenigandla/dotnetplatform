﻿using System;

namespace Oop
{
    class Program
    {
        static void Main(string[] args)
        {
            // Customer cust = new Customer(1234, "Shobhan", "sbsthegreat321@gmail.com",813041999,"Pune, Maharashtra","Yes a Loyal Member");
            //cust.Display();

            Employee employee1 = new Employee();
            employee1.Id = 2435;
            employee1.FirstName = "abc";
            employee1.LastName = "xyz";
            employee1.Designation = "Clerk";
            employee1.Gender = "female";
            employee1.Email = "abcxyz@gmail.com";
            employee1.Display();

            Employee employee2 = new Employee(1234, "Raaj", "Kumar", "Male", "rajkumar@google");
            employee2.Display();
        }
    }
}
