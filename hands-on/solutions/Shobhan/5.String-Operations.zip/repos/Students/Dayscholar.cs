﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Students
{
    public class Dayscholar : Students
    {
        public Dayscholar(string start, string end, double fee, int total_act)
        {
            this.fee = fee;
            this.start = start;
            this.end = end;
            this.total_act = total_act;
        }
        public override void Display()
        {
            fee = fee + (fee*0.15);
            Console.WriteLine("Dayscholar fees is: " + fee);
            Console.WriteLine("All shift Timings for school are between: " + start + " and " + end);
            Console.WriteLine("Total no of activities in a day : " + total_act + "\n\n");
        }
    }
}
