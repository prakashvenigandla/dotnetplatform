﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Students
{
    public class Hosteller : Students
    {
        public Hosteller(string start, string end , double fee, int total_act)
      {
            this.fee = fee;
            this.start = start;
            this.end = end;
            this.total_act = total_act;
        }
         public override void Display()
        {
            fee = fee + (fee * 0.30);
            Console.WriteLine("Hostler fees is: " + fee);
            Console.WriteLine("Timings for school are between: "+start+" and "+end);
            Console.WriteLine("Total no of activities in a day : "+total_act+"\n\n");
        }
    }
}
