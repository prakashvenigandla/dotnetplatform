﻿using System;
using System.Collections.Generic;
using System.Text;
namespace Students
{
    public class Students
    {
        protected string name;
        protected int roll;
        protected string start;
        protected string end;
        protected double fee;
        protected int total_act;
        public Students()
        { }
        public Students(string name, int roll)
        {
            this.name = name;
            this.roll = roll;
        }
        public virtual void Display()
        {
            Console.WriteLine("Name of student is: " + name);
            Console.WriteLine("Roll No of student is: " + roll);           
           
        }
    }
}
