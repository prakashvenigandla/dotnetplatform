﻿using System;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            Shapes shape = new Shapes("Red");
            shape.Draw();

        }
    }
}
