﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Shapes
{
    public class Shapes
    {
        protected string color;
        public Shapes(string color)
        {
            this.color = color;
        }

        public virtual void Draw()
        {
            Console.WriteLine("Drawing Shape in {0}",color);
        }

    }

}
