﻿using System;

namespace StringOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "Shobhan";
            string s2 = "Shobhan Sharma";
            char[] ch = { 'S', 'h', 'o', 'b', 'h', 'a','n' };
            string s3 = new string(ch);
            int a = 1234;
            
            Console.WriteLine(s1);
            Methods method = new Methods("Shobhan Bhavesh");

            Console.WriteLine("Lower: "+s1.ToLower());
            Console.WriteLine("Upper: "+s3.ToUpper()+"\n");

            Console.WriteLine(s3);
            Console.WriteLine(s3.CompareTo(s1)+"\n");

            Console.WriteLine(s1.Equals(s2).Equals(s3));
            Console.WriteLine(s1.Equals(s3));

            string s4 = a.ToString();
            Console.WriteLine("String 1234: "+s4);

            Console.WriteLine("Trim End: " + s2.TrimEnd(ch));
            Console.WriteLine("Trim Start: " + s2.TrimStart(ch));

            Console.WriteLine(s2.Insert(8,"Bhavesh "));

            string[] s5 = { "Shobhan has done:", "C#", "for", ".Net practice" };
            string s6 = string.Join("-", s5);
            Console.WriteLine(s6);







        }
    }
}
