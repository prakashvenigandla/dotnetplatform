﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StringOperations
{
    class Methods
    {
        public Methods(string s1)
        {
           Console.WriteLine(s1.IndexOf("a"));
            

        }
    }
}
