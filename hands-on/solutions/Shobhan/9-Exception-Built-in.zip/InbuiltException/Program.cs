﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InbuiltException
{
    class Program
    {
        static void Main(string[] args)
        {
            try//Argument out of range(>18)
            {
                Guest guest1 = new Guest("SB", "S", 17);
                Console.WriteLine(guest1.GuestInfo());

            }
            catch (ArgumentOutOfRangeException outOfRange)
            {
                Console.WriteLine("Error: "+ outOfRange.Message);
            }

            try
            {
                Guest guest2 = new Guest("\n SB", "S", 19);
                Console.WriteLine(guest2.GuestInfo());
            }
            catch (ArgumentOutOfRangeException outOfRange)
            {
                Console.WriteLine("Error: " + outOfRange.Message);
            }

            try // Invalid Type Casting
            {

                var book = new Book("\n Sbs is working", "on .Net");
                var castBook = (PublishedBook)book;
                Console.WriteLine("\n Casting successful:");
                Console.WriteLine(castBook);
            }
            catch (InvalidCastException exception)
            {
                Console.WriteLine("\n Casting failed.");
                Console.WriteLine(exception);
            }

           
            try // Index out of range
            {
                int[] n = new int[5] { 66, 33, 56, 23, 81 };
                int i, j;
                for (j = 0; j < 10; j++)
                {
                    Console.WriteLine("\n Element[{0}] = {1}", j, n[j]);
                }
                Console.ReadKey();
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine(e);
            }

            try // Argument Null
            {

                var book = new Book("\n Sbs is working", null);

            }
            catch (ArgumentNullException exception)
            {
                
                Console.WriteLine("\n Error"+exception.Message);
            }

            try
            {
                List<String> names = new List<String>();
                names.Add("Major Major Major");
                throw new NullReferenceException("Null Refrence passed \n");
            }
            catch (NullReferenceException exception)
            {
                Console.WriteLine("\n Error: "+ exception.Message);            
            }

        }
    }
}
