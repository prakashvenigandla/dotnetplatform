﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InbuiltException
{
    class Book
    {
        public string Title { get; set; }
        public string Task { get; set; }

        public Book(string title, string task)
        {
            if (title == null)
            {
                throw new ArgumentNullException("title", "Title Argument passed as null");
            }
            else if (task == null)
            {
                throw new ArgumentNullException("task", "Task Argument passed as null");
            }
            else
            {
                Title = title;
                Task = task;
            }
        }
    }
}
