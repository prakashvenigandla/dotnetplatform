﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InbuiltException
{
    class Guest
    {
        private string FirstName;
        private string LastName;
        private int Age;

        public Guest(string fName, string lName, int age)
        {
            FirstName = fName;
            LastName = lName;
            if (age < 18)
                throw new ArgumentOutOfRangeException("age", "The Voter must be greater than 18 for eligible to vote");
            else
                Age = age;
        }

        public string GuestInfo()
        {
            string gInfo = FirstName + " " + LastName + ", " + Age.ToString();
            return (gInfo);
        }
    }
}
