﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InbuiltException
{
    class PublishedBook : Book
    {
        public DateTime PublishedAt { get; set; }

        public PublishedBook(string title, string task, DateTime published_at)
            : base(title, task)
        {
            Title = title;
            Task = task;
            PublishedAt = published_at;
        }
    }
}
