﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Oop
{
    class Customer
    {
        private int id; 
        private string name;
        private int mobile;
        private string lmember;
        private string email;
        private string address;
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Mobile { get; set; }
        public string Address { get; set; }
        public string Lmember { get; set; }
        public Customer(int id, string name, string email, int mobile, string address, string lmember)
        {
            Id = id;
            Name = name;
           Email = email;
           Mobile = mobile;
            Address = address;
            Lmember = lmember;

        }
      
        public void Display() 
        {
            Console.Write("The customer Information is: ");
            Console.WriteLine("Employee info is : Id =  " +Id +"\nName = "+ Name + "\nEmail = " + Email + "\nMobile = " + Mobile + "\nAddress = " + Address + "\nLoyalty Memberhip = " + Lmember);

        }

    }
}
