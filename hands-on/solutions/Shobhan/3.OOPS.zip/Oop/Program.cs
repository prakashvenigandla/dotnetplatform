﻿using System;

namespace Oop
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer cust = new Customer(1234, "Shobhan", "sbsthegreat321@gmail.com",813041999,"Pune, Maharashtra","Yes a Loyal Member");
            cust.Display();
        }
    }
}
