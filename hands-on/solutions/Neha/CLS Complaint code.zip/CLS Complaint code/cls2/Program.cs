﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clsprogram;
using clsVb;

namespace cls2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1();
            obj.Calucualte(2);
            Class2 obj1 = new Class2();
            obj1.Calucualte(2);
        }
    }
}
