﻿using System;

namespace cls
{
    public class Class1
    {
    }
}
