﻿Public Class Class2
    Public Sub Add(a As Integer, b As Integer)
        Console.WriteLine(a + b)
    End Sub
End Class
