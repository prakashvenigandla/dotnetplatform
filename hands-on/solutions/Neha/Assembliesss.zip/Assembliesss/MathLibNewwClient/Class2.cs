﻿using System;

namespace MathLibNewwClient
{
    internal class Class2
    {
        internal void Add(int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}