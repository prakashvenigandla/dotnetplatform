﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibNeww;
using MathLibNewwVb;
namespace MathLibNewwClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj1 = new Class1();
            Console.WriteLine(obj1.Add(1, 2));
            Console.ReadLine();
            Class2 obj2 = new Class2();
            obj2.Add(2, 5);
        }
    }
}
