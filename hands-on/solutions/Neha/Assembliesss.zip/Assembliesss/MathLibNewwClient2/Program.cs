﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibNeww;

namespace MathLibNewwClient2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class2 obj2 = new Class2();
            Console.WriteLine(obj2.Add(4, 5));
            Console.ReadLine();
        }
    }
}
