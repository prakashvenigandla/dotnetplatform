﻿using System;

namespace MathLibNewwClient2
{
    internal class Class2
    {
        internal bool Add(int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}