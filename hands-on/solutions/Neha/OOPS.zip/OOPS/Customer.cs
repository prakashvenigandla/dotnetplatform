﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS
{
    class Customer
    {
		         /*public int Id;
		           public string Name;
		           public string Email;
		           public int Mobile;
		           public string Address;
		           public string loyaltyMembership;*/

		public int Id { get; set; }
		public string Name { get; set; }
		public string Email { get; set; }
		public int Mobile { get; set; }
		public string Address { get; set; }
		public string loyaltyMembership { get; set; }

		public Customer(int id, string name, string email, int mobile, string address, string loyal_m)
		{
			this.Id = id;
			this.Name = name;
			this.Email = email;
			this.Mobile = mobile;
			this.Address = address;
			this.loyaltyMembership = loyal_m;
		}

		public void Display()
		{
			Console.WriteLine("Customer Details\n");
			Console.WriteLine("ID of Customer: {0}\nName of Customer: {1}\nEmail of Customer: {2}\nMobile no. of Customer: {3}\nAddress of Customer: {4}\nLoyaltyMembership: {5}", Id, Name, Email, Mobile, Address, loyaltyMembership);
		}
	}
}
