﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS
{
    class Program
    {
        static void Main(string[] args)
        {
                Customer newcustom = new Customer(5555, "Gurleen", "G12@gmail.com", 99786 , "Jammu", "Yes");
                newcustom.Display();
        }
    }
}
