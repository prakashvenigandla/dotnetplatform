﻿using System;

namespace STUDENT
{
    class Program
    {
        static void Main(string[] args)
        {
            Studentdetails student1 = new Studentdetails("neha", 78);
            student1.Display();
            Hosteller hostel = new Hosteller(918217236, 100000.25, 10);
            hostel.Display();
            Studentdetails student2 = new Studentdetails("kavya", 35);
            student2.Display();
            Dayscholardetails.Dayscholar dayscholar = new Dayscholardetails.Dayscholar(951570716, 100000.25, 5);
            dayscholar.Display();




        }
    }
}
