﻿using System;
using System.Collections.Generic;
using System.Text;

namespace STUDENT
{
    class Studentdetails
    {
        protected string name;
        protected int roll;
        protected int mobile;
        protected double fee;
        protected int no_activities;
        public Studentdetails()
        {
        }
        public Studentdetails(string name, int roll)
        {
            this.name = name;

            this.roll = roll;
        }
        public virtual void Display()
        {
            Console.WriteLine("student name is:" + name);
            Console.WriteLine("Enroll of student is:" + roll);
        }

    }
}
