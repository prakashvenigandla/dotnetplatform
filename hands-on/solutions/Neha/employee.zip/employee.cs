﻿using System;
    class Employee
    {

        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Designation { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }

        public Employee(int id, string firstName, string lastName, string designation, string gender, string email)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Designation = designation;
            Gender = gender;
            Email = email;
        }
        public void Display()
        {
            Console.WriteLine("Employee info");
            Console.WriteLine("Id:{0} FirstName:{1} LastName:{2} Designation:{3} Gender:{4} Email:{5}",
                Id, FirstName, LastName, Designation, Gender, Email);
        }
        public int CaluculateSalary()
        {
            return 0;
        }
        public void SwipeIn()
        {

        }
        public void Swipeout()
        {

        } 
    }


