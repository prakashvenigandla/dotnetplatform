﻿using System;

namespace EB_Bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int eunit, amt = 0;
            double gst, total;
            Console.WriteLine("Enter your electricity units: ");
            eunit = Convert.ToInt32(Console.ReadLine());
            if (eunit < 101)
            {
                amt = eunit * 5;

            }
            else if (eunit > 100 && eunit < 201)
            {
                amt = (eunit - 100) * 7 + 500;
            }
            else if (eunit > 200 && eunit < 301)
            {
                amt = (eunit - 200) * 10 + 500 + 700;
            }
            else if(eunit>300 && eunit < 401)
            {
                amt = (eunit - 300) * 12 + 500 + 700 + 1000;
            }
            else if (eunit > 400)
            {
                amt = eunit * 15;
            }
            else
            {
                Console.WriteLine("invalid input");
            }
            Console.WriteLine("your bill is amount Rs " + amt);
            gst = amt * 0.14;
            Console.WriteLine("GST for your bill is Rs " + gst);
            total = gst + amt;
            Console.WriteLine("your total bill including GST is Rs " + total);

        }
    }
}
