﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPs
{
    class customer_details
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public long Mobile { get; set; }
        public string LoyaltyMember { get; set; }
        public string Address { get; set; }


        public customer_details(int id, string name, string email, long mobile, string loyaltyMember, string address)
        {
            Id = id;
            Name = name;
            Email = email;
            Mobile = mobile;
            LoyaltyMember = loyaltyMember;
            Address = address;
        }
        public void display()
        {
            Console.WriteLine("customer details are....");
            Console.WriteLine("________________________");
            Console.WriteLine("ID = {0}\n NAME = {1}\n EMAIL = {2}\n MOBILE = {3}\n LOYALTY MEMBER = {4}\n ADDRESS = {5}\n",Id,Name,Email,Mobile,LoyaltyMember,Address);

        }
    }
    

}

