﻿using System;

namespace OOPs
{
    class Program
    {
        static void Main(string[] args)
        {
            customer_details cust = new customer_details(11256, "siddharth", "sid@gmail.com", 8982898289, "special", "ghar");
            cust.display();
        }
    }
}
