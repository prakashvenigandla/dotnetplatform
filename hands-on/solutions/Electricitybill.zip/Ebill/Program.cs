﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ebill
{
    class Program
    {
        static void Main(string[] args)
        {
                string name;
                Console.WriteLine("Enter the name of customer:");
                Console.ReadLine();
                int units;
                int bill = 0;
                double gst, total;
                Console.WriteLine("Enter no. of units consumed: ");
                units = Convert.ToInt32(Console.ReadLine());
                if (units <= 100)
                {
                    bill = bill + (5 * units);
                }
                else if (units <= 200 && units > 100)
                {
                    bill = (units - 100) * 7 + 500;
                }
                else if (units <= 300 && units > 200)
                {
                    bill = (units - 200) * 10 + 500 + 700;
                }
                else
                {
                    bill = (units - 300) * 12 + 500 + 700 + 1000;
                }
                Console.WriteLine("The bill of units consumed is :" + bill);
                gst = bill * 14 / 100;
                Console.WriteLine("Gst is:" + gst);
                total = bill + gst;
            Console.WriteLine("Total amount to be paid by is:{total}");
            }
        }
    }

