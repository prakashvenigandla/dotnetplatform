--Hands-on-I
--1)
EXEC sp_help 'AdventureWorks2019.HumanResources.Employee'
--2)
select *
from HumanResources.Employee
--3)
select * 
from HumanResources.Department
--4)
EXEC sp_help 'AdventureWork2019.Production.Product'
--5)
select	BusinessEntityID,
		Jobtitle,
		Hiredate
from HumanResources.Employee
--6)
select ProductID,	
	   Name,
	   StandardCost 
from Production.Product
--7)
select * 
from Production.Product