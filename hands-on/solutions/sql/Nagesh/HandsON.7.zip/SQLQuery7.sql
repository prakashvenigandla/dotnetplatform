--I
CREATE TABLE Department
(
	DepartmentID smallint identity(100,10) primary key,
	DeptName	 varchar(50) unique,
	GroupName	 varchar(50) not null,
	Location	 varchar(30)
)

--II
CREATE TABLE Employee
(
	EmployeeID		smallint identity(1001,1) primary key,
	EmpName			varchar(100) not null,
	DateOFJoin		datetime ,
	Designation		varchar(50),
	CostToCompany	money,
	DepartmentID	smallint 
)

--III
SP_HELP Department
SP_HELP Employee

--IV
alter table Employee add constraint ck_EMP_DateOFJoin 
CHECK (DateOFJoin <= getdate())
 
--V
alter table Employee add DepartmentHead smallint,
constraint fk_key_DeptHead foreign key (DepartmentHead) references Employee(EmployeeID)

--VI
create table SalesOrder
(
    OrderID	     int identity(1,1)primary key,
	OrderDate	 datetime default getdate(),
	Duedate		 datetime,
	ShippingDate datetime
)

--VII
alter table SalesOrder add OrderValue money
select * from SalesOrder

--VIII
alter table SalesOrder drop column ShippingDate

--IX
SP_HELP SalesOrder

--X
drop table SalesOrder


