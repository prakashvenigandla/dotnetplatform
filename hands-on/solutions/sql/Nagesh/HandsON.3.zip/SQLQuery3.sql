--I:
select * from Person.Person
where LEN(MiddleName)>1 and MiddleName not like '%.'

--II
SELECT  upper(concat(FirstName,' ',MiddleName,' ',LastName )) as FullName 
from person.person

--III
select  ROUND(LineTotal,2)as linetotal 
from Sales.SalesOrderDetail 

--IV
select CURRENT_TIMESTAMP

--V
select*from HumanResources.Employee 
where DATEDIFF(year,HireDate,Current_timestamp)>10 order by HireDate

--VI
select * from Sales.SalesOrderHeader 
where format(OrderDate,'MM')=2

--VII
select ProductID,Name  ,COALESCE(color,'no color')from Production.Product 

--VIII
SELECT *,format(BirthDate,'MMMM DD,yyyy') AS birthdate from HumanResources.Employee