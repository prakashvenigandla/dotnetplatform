
--I
True

--II
False

--III
True

--IV
select max(LineTotal) as Max, avg(LineTotal) as Avg, min(LineTotal) as Min from 
Sales.SalesOrderDetail

--V
select SalesOrderID,max(LineTotal) as Max, avg(LineTotal) as Avg, min(LineTotal) as Min
from Sales.SalesOrderDetail group by SalesOrderID

--VI
select Count(BusinessEntityID)as No_of_Emp,JobTitle 
from HumanResources.Employee group by JobTitle order by JobTitle

--VII
select * from HumanResources.JobCandidate 
where BusinessEntityID is not null

--VIII
select SalesOrderID, UnitPrice 
from Sales.SalesOrderDetail where UnitPrice>25000

--IX
select DepartmentID,count(BusinessEntityID)As Total_Employee 
from HumanResources.EmployeeDepartmentHistory group by DepartmentID

--X
select Count(DepartmentID) as Dept_Exp,BusinessEntityID 
 FROM HumanResources.EmployeeDepartmentHistory 
 GROUP BY BusinessEntityID having  Count(DepartmentID)>2