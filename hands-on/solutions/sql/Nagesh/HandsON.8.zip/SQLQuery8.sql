
--I

insert into Department(DeptName,GroupName,Location) values('HumanResources'  ,'Operations' ,'NewDelhi' )
insert into Department(DeptName,GroupName,Location) values('Administrations' ,'Operations' ,'Hyderabad')
insert into Department(DeptName,GroupName,Location) values('Production'      ,'Inward'     ,'Bengaluru')
insert into Department(DeptName,GroupName,Location) values('Finance'         ,'Operations' ,'Chennai'  )
insert into Department(DeptName,GroupName,Location) values('Sales'           ,'Outward'    ,'Mumbai'   )
insert into Department(DeptName,GroupName)          values('Purchasing'      ,'Inward'    )
insert into Department(DeptName,GroupName)          values('PublicRelation'  ,'Operations')

--II

insert into Employee(EmpName,DateOFJoin,Designation,CostToCompany,DepartmentID)values('Manoj'   ,'29-Jan-93' ,'CEO',1500000,110)
insert into Employee(EmpName,DateOFJoin,Designation,CostToCompany,DepartmentID)values('Suren'   ,'05-NOV-90' ,'Sr.Manager',1000000,160)
insert into Employee(EmpName,DateOFJoin,Designation,CostToCompany,DepartmentID)values('Bhaskar' ,'09-Jul-98' ,'Sr.Manager',1200000,140)
insert into Employee(EmpName,Designation,CostToCompany,DepartmentID)           values('Arijit'  ,'Manager'   ,500000,120)
insert into Employee(EmpName,Designation,CostToCompany,DepartmentID)           values('Ravindra','Executive' ,500000,110)
insert into Employee(EmpName,Designation,CostToCompany,DepartmentID)           values('Kishor'  ,'Manager'   ,600000,150)
insert into Employee(EmpName,Designation,CostToCompany,DepartmentID)           values('Mathew'  ,'Manager'   ,800000,140)
insert into Employee(EmpName,DateOFJoin,Designation,DepartmentID   )           values('Rachna'  ,'31-Oct-09' ,'Executive',120)
insert into Employee(EmpName,DateOFJoin,DepartmentID)                          values('Nilesh'  ,'14-Sep-09' ,160)
insert into Employee(EmpName,Designation,CostToCompany,DepartmentID)           values('Hari'    ,'Manager'   ,800000,140)
insert into Employee(EmpName,DateOFJoin,DepartmentID)                          values('Ananta'  ,'01-Aug-08' ,120)

--III

update Employee set DateOfJoin='2005-02-01' where  EmpName='Arijit'
update Employee set DateOfJoin='2006-06-16' where  EmpName='Mathew'
update Employee set DateOfJoin='2007-08-04' where  EmpName='Hari'
update Employee set DateOfJoin='2008-03-22' where  EmpName='Kishor'
update Employee set DateOfJoin='2010-01-01' where  EmpName='Ravindra'

--IV

update  Department  set DepartmentHead='Suren'
where   DeptName    ='HumanResources'
update  Department  set  DepartmentHead='Manoj'
where   DeptName    ='Administrations'
update  Department  set  DepartmentHead='Mathew'
where   DeptName    ='Sales'
update  Department  set  DepartmentHead='Bhaskar'
where   DeptName    ='PublicRelation'

--v

delete from Employee
where EmpName='Ananta'