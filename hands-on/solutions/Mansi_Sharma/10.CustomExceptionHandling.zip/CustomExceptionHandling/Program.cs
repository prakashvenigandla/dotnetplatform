﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            int LoadOnLift;
            Lift L1 = new Lift();
            L1.DesiredValue = 400;
            Console.WriteLine("Enter the load on the lift:");
            LoadOnLift=Convert.ToInt32(Console.ReadLine());
            L1.TotalLoad(LoadOnLift);

            L1.EmergencyHelp();
        }
    }
}
