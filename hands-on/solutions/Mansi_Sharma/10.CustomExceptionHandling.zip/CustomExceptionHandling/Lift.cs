﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionHandling
{
    public class Lift
    { 
        public Lift()
        {

        }
        public int LoadOnLift { get; set; }
        public int DesiredValue { get; set; }
        public void EmergencyHelp()
        {
            Console.WriteLine("Warning!! In Case of Emergency or any mishap press Emergency Button.");

        }
        public void TotalLoad(int LoadOnLift)
        {
            try
            {
                if (LoadOnLift > DesiredValue)
                {

                    throw new OverLoadException(
                        string.Format("Due to Over Loading Lift cannot move .So for proper functioning of Lift ,You have to maintain the desired value."));
                }
                else
                {
                    Console.WriteLine("Check whether the lift door is closed properly or not brfore it starts moving.");
                }

            }
            catch (OverLoadException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

