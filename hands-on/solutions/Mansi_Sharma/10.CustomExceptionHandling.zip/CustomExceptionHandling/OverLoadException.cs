﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionHandling
{
    class OverLoadException:ApplicationException
    {
        public OverLoadException(string message) : base(message)
        {
        }
    }
}

