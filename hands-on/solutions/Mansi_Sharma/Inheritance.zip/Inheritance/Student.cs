﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Student
    {
        public String studentName;
        public string department;
        public int rollNo;
        //public string blockName;
        //public double hostelFee;
        //public double messCharge;
        //public double totalFee;
        //public double tuitionFee;
        //public double trasportationFee;

        public Student()
        {
        }

        
        public Student(string name, string dept, int rollno)
        {
            this.studentName = name;
            this.department = dept;
            this.rollNo = rollno;
        }
        public virtual void Display()
        {
            Console.WriteLine("The name of student is  " + studentName);
            Console.WriteLine("Student belongs to " + department + " Department");
            Console.WriteLine("The roll no.  of student is " + rollNo);
        }
    }
}
