﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Hostlers:Student
    {
        public string blockName;
        public double hostelFee;
        public double messCharge;
        public double totalFee;
        public double tuitionFee;
        

        public Hostlers()
        {
        }
         public Hostlers(String BlockName,double HostelFee, double MessCharge,double TuitionFee)
        {
            blockName = BlockName;
            hostelFee = HostelFee;
            messCharge = MessCharge;
            tuitionFee = TuitionFee;
        }
        
        public override void Display()
        {
            totalFee = hostelFee + messCharge + tuitionFee;
            Console.WriteLine("Block Name of the hostel is :{0}", blockName);
            Console.WriteLine("Hostel Fee  is :{0}",hostelFee);
            Console.WriteLine("Mess Fee of the hostel is :{0}", messCharge);
            Console.WriteLine("Tuition Fee of the student is :{0}", tuitionFee);
            Console.WriteLine("Total Fee is :" + totalFee);
        }
    }
}
