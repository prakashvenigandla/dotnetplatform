﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Student s = new Student("Mansi Sharma","Engineering",123);
            s.Display();
            Hostlers h = new Hostlers("Himalaya", 50000, 30000, 80000);
            h.Display();
            Console.ReadLine();
            Student S = new Student("Kanchan Sharma", "Management", 678);
            S.Display();
            DaySchoolars d = new DaySchoolars("Not opted for hostel", 0, 0, 80000, 40000);
            d.Display();

        }
    }
}
