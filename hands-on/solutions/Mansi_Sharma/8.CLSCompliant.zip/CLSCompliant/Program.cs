﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
[assembly:CLSCompliant(true)]
namespace CLSCompliant
{
   [CLSCompliant(false)]
    public class Program
    {
        public int Add(int a,int b)
        {
            return a + b;
          
        }
        public int add(int a,int b)
        {
            return a + b;
        }
        static void Main(string[] args)
        {
            Program obj = new Program();
            int res=obj.Add(80, 4);
            Console.WriteLine("Result:{0}",res);
            int res1 = obj.add(8, 4);
            Console.WriteLine("Result1:{0}",res1);
        }
    }
}
