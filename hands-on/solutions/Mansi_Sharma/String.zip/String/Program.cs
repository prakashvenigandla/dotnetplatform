﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace String
{
    class Program
    {
       
        public  static void  Equals()
        {
            string s1 = @"hello";
            string s2 = @"hello";
            string s3 = @"csharp";
            Console.WriteLine(s1.CompareTo(s2));
            Console.WriteLine(s2.CompareTo(s3));
            Console.ReadLine();
        }


        public static void Main()
        {
            //to display strings
            string str1 = "Hello";
            char[] ch = { 'a', 'b' };
            char[] ch1 = { 'm', 'a', 'n' };
            string str2 = new string(ch);
            string str3 = new string(ch1);
            Console.WriteLine("String 1 is :{0} \nString 2 is :{1}\nString 3 is:{2}", str1, arg1: str2, str3);
            Console.ReadLine();

            string str4 = str3.Insert(2, " ");
            Console.WriteLine("String 4 is :{0}", str4);
            Console.ReadLine();


            //to compare strings
            string s1 = "hello";
            string s2 = "hello";
            string s3 = "csharp";
            string s4 = "mello";
            string s5 = "GOOD MORNING";

            Console.WriteLine(string.Compare(s1, s2));
            Console.WriteLine(string.Compare(s2, s3));
            Console.WriteLine(string.Compare(s3, s4));
            Console.ReadLine();

            Console.WriteLine(string.CompareOrdinal(s1, s2));
            Console.WriteLine(string.CompareOrdinal(s1, s3));
            Console.WriteLine(string.CompareOrdinal(s1, s4));
            Console.ReadLine();

            //to concat strings
            Console.WriteLine(string.Concat(s1, s2));
            Console.WriteLine(string.Concat(s1, s2, s3));
            Console.WriteLine(string.Concat(s1, s4));
            Console.ReadLine();

            //to check whether equal or not
            Console.WriteLine(string.Equals(s1, s2));
            Console.WriteLine(string.Equals(s1, s3));
            Console.WriteLine(string.Equals(s1, s4));
            Console.ReadLine();

           
            Equals();
            Console.ReadLine();

            //to  convert string to uppercase
            Console.WriteLine(s1.ToUpper());
            Console.ReadLine();

            //to convert string to lowercase
            Console.WriteLine(s5.ToLower());
            Console.ReadLine();

            Console.WriteLine(s1.TrimStart('o'));
            Console.WriteLine(s1.TrimStart('l'));
            Console.WriteLine(s1.TrimEnd('o'));




        }
    }
}
