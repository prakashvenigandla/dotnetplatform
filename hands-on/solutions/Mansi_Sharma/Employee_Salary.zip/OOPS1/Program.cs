﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS1
{
    class Program
    {
        static void Main()
        {

            string empName;
            double basicSalary;
            Console.WriteLine("Enter the name of the customer:");
            empName = Console.ReadLine();
            Console.WriteLine("Enter the salary:");
            basicSalary = Convert.ToDouble(Console.ReadLine());
            Employee1 employee = new Employee1(empName,basicSalary);
            employee.Display();
        }
    }
}
