﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPS1
{
    class Employee1
    {
        public string empName { get; set; }
        public double basicSalary { get; set; }
        public double hra { get; set; }
        public double da { get; set; }
        public double tax { get; set; }
        public double grossPay { get; set; }
        public double netSalary { get; set; }

        public Employee1(string EmpName, double BasicSalary)
        {
            this.empName = EmpName;
            this.basicSalary = BasicSalary;
        }

        
        public void CalculateNetPay()
        {
            hra = 0.15 * basicSalary;
            da = 0.1 * basicSalary;
            grossPay = basicSalary + hra + da;
            tax = 0.08 * grossPay;
            netSalary = grossPay - tax;
        }
        public void Display()
        {
            CalculateNetPay();
            Console.WriteLine("Salary Details of Employee is as under:");
            Console.WriteLine("DA:" + da);
            Console.WriteLine("HRA:" + hra);
            Console.WriteLine("GrossPay:" + grossPay);
            Console.WriteLine("Tax:" + tax);
            Console.WriteLine("Net salary:" + netSalary);
        }
    }
}

