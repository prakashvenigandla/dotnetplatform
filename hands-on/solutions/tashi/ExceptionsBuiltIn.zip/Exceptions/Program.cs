﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, res=0;
            Console.WriteLine("enter first no.:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter second no.: ");
            b = Convert.ToInt32(Console.ReadLine());
            try
            {
                res = a / b;
            }
            catch(Exception dbe)
            {
                Console.WriteLine(dbe.Message);
            }
            Console.WriteLine(res);
            try
            {
                int[] myNumbers = { 1, 2, 3 };
                Console.WriteLine(myNumbers[10]);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            try
            {
                string s1 = null;
                Console.WriteLine("calculate".IndexOf(s1));
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            try
            {
                string s3 = "helloworld";
                Console.WriteLine(s3[13]);
            }
            catch(IndexOutOfRangeException ire)
            {
                Console.WriteLine(ire.Message);
            }
          
        }
    }
}
