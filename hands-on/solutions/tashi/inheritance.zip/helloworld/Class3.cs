﻿using System;


namespace helloworld
{
    class DayScholar : Student
    {
        public string Address { get; set; }
        public string Conveyance { get; set; }
        

        public DayScholar()
        {

        }
        public DayScholar(string address, string conveyance, int tuitionFee)
        {
            Address = address;
            Conveyance = conveyance;
            TuitionFee = tuitionFee;
        }
        public override void Display()
        {
            Console.WriteLine("Student's Permanent Address: {0}", Address);
            Console.WriteLine("Mode of Transport:           {0}", Conveyance);
            Console.WriteLine("Fees:                        {0}", TuitionFee);
            Console.WriteLine("\n");
        }
    }
}
