﻿using System;


namespace helloworld
{
    class Program
    {
        public static void Main(string[] args)
        {
            Student s1 = new Student("Jay", 6001, "6-C", "jay@gmail.com", 30000);
            s1.Display();
            s1 = new Hosteller("Hostel B", "Swimming, Horse Riding", 40000, 30000);
            s1.Display();
            Student s3 = new Student("Raj", 6009, "6-C", "raj@gmail.com", 30000);
            s3.Display();
            s3 = new Hosteller("Hostel F", "Horse Riding, Tennis", 45000, 30000);
            s3.Display();
            Student s2 = new Student("Ben", 6004, "6-C", "ben@gmail.com", 50000);
            s2.Display();
            s2 = new DayScholar("22 Baker Street", "Bus", 50000);
            s2.Display();
            
        }
    }
}
