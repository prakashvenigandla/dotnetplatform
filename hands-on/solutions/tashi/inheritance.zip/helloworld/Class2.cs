﻿using System;


namespace helloworld
{
    class Hosteller : Student
    {
        public string HostelWing { get; set; }
 
        public string EveActivity { get; set; }
        public int HostelFees { get; set; }
        public Hosteller()
        {

        }
        public Hosteller(string hostelWing, string eveActivity, int hostelFees, int tuitionFee)
        {
            
            HostelWing = hostelWing;
            EveActivity = eveActivity;
            HostelFees = hostelFees;
            TuitionFee = tuitionFee;
        }
        public override void Display()
        {
            
            Console.WriteLine("Student lives in Hostel Wing: {0}", HostelWing);
            Console.WriteLine("Evening activities :          {0}", EveActivity);
            Console.WriteLine("Fees with Hostel Fees:        {0}", TuitionFee + HostelFees);
            Console.WriteLine("\n");
        }
    }
}
