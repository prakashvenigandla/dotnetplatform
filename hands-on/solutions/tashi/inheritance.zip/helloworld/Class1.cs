﻿using System;


namespace helloworld
{
    public class Student
    {
        public string Name { get; set; }
        public int RollNo { get; set; }
        public string ClassSection { get; set; }
        public string Email { get; set; }
        public int TuitionFee { get; set; }

        public Student(string name, int rollNo, string classSection, string email, int tuitionFee)
        {
            Name = name;
            RollNo = rollNo;
            ClassSection = classSection;
            Email = email;
            TuitionFee = tuitionFee;

        }
        public Student()
        {

        }
        public virtual void Display()
        {
            Console.WriteLine("Name of Student:              {0}", Name);
            Console.WriteLine("Roll No of Student:           {0}", RollNo);
            Console.WriteLine("Class and Section of Student: {0}", ClassSection);
            Console.WriteLine("Email of Student:             {0}", Email);
            Console.WriteLine("Tuition Fee:                  {0}", TuitionFee);
            
        }
    }
}
