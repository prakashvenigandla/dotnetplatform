﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationExcp
{
    class Admin
    {
        public string Name { get; set; }
        public string Pass { get; set; }
        public Admin(string name, string pass)
        {
            Name = name;
            Pass = pass;
        }
        public void Enter(string pass)
        {
            try
            {
                if (pass != "root")
                {
                    throw new AccessDeniedException("Wrong Password");

                }
                Console.WriteLine("Access Granted");
            }
            catch(AccessDeniedException ade)
            {

                Console.WriteLine(ade.Message);
            }
        }
    }
}
