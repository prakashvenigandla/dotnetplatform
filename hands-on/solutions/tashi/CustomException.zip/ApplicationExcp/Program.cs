﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationExcp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Name");
            string nam = Console.ReadLine();
            Console.WriteLine("Enter Pas");
            string pas = Console.ReadLine();
            Admin a1 = new Admin(nam,pas);
            a1.Enter(pas);
        }
    }
}
