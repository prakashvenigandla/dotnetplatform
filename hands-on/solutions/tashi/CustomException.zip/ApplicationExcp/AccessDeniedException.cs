﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationExcp
{
    class AccessDeniedException:ApplicationException
    {
        public AccessDeniedException(string message) : base(message)
        {

        }
    }
}
