﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionFunds
{
    class Program
    {
        static void Main(string[] args)
        {
            int opt;
            int saccno, daccno;
            string sifsc, difsc;
            double amt;
            Account a1 = new Account(1234, "Jon", "Savings", 50000, "AF0009", "XYZ");
            Account a2 = new Account(5678, "Bec", "Savings", 60000, "GK7000", "ABC");
            double prevBal1 = a1.Balance;
            double prevBal2 = a2.Balance;
            a1.DisplayDetail();
            a2.DisplayDetail();
            Console.WriteLine("Select option:");
            Console.WriteLine("1.NEFT");
            Console.WriteLine("2.IMPS");
            opt = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Source Account Details:\n Account Number:");
            saccno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("IFSC:");
            sifsc= Console.ReadLine();
            Console.WriteLine("Amount to transfer:");
            amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Destination Account Details:\n Account Number:");
            daccno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("IFSC:");
            difsc = Console.ReadLine();
            if (saccno == a1.AccountNumber)
            {
                a1.Balance -= amt;
                a2.Balance += amt;
                


                try
                {
                    if (a1.Balance != prevBal1 - amt || a2.Balance != prevBal2 + amt)
                    {
                        throw new TransactionFailedException("Transaction could not be completed please try again later");
                    }
                    Console.WriteLine("Transaction successful");
                }
                catch (TransactionFailedException tfe)
                {
                    Console.WriteLine(tfe.Message);
                }
            }
            if (saccno == a2.AccountNumber)
            {
                a2.Balance -= amt;
                a1.Balance += amt;
                

                try
                {
                    if (a2.Balance != prevBal2 - amt || a1.Balance != prevBal1 + amt)
                    {
                        throw new TransactionFailedException("Transaction could not be completed please try again later");
                    }
                    Console.WriteLine("Transaction successful");
                }
                catch (TransactionFailedException tfe)
                {
                    Console.WriteLine(tfe.Message);
                }
            }
        }
    }
}
