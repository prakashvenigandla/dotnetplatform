﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionFunds
{
    class TransactionFailedException:ApplicationException
    {
        public TransactionFailedException(string message):base(message)
        {

        }
    }
}
