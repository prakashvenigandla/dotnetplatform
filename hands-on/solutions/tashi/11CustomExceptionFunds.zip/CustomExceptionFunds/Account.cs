﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptionFunds
{
    class Account
    {
        public int AccountNumber { get; set; }
        public string Name { get; set; }
        public string AccountType { get; set; }
        public double Balance { get; set; }
        public string Ifsc { get; set; }
        public string Branch { get; set; }
        public Account(int accountNumber, string name, string accountType, double balance, string ifsc, string branch)
        {
            AccountNumber = accountNumber;
            Name = name;
            AccountType = accountType;
            Balance = balance;
            Ifsc = ifsc;
            Branch = branch;

        }
        public void DisplayDetail()
        {
            Console.WriteLine("The Account Details:");
            Console.WriteLine("Account NUmber: {0}",AccountNumber);
            Console.WriteLine("Name: {0}", Name);
            Console.WriteLine("Account Type: {0}", AccountType);
            Console.WriteLine("IFSC Code: {0}", Ifsc);
            Console.WriteLine("Balance: {0}", Balance);
            Console.WriteLine("Branch: {0}", Branch);
            Console.WriteLine();
        }
    }
}
