﻿using System;


namespace ebill
{
    class Program
    {
        static void Main(string[] args)
        {
            int eunits, bill=0;
            double gst, tot;
            Console.WriteLine("Enter units consumed");
            eunits = Convert.ToInt32(Console.ReadLine());
            if (eunits < 101)
            {
                bill = eunits * 5;
            }
            else if (eunits<201 && eunits > 100)
            {
                bill = 500 + (eunits - 100) * 7;
            }
            else if (eunits < 301 && eunits > 200)
            {
                bill = 500 + 700 + (eunits - 200) * 10;
            }
            else if (eunits < 401 && eunits > 300)
            {
                bill = 500 + 700 + 1000 + (eunits - 300) * 12;
            }
            else if (eunits > 400)
            {
                bill = 500 + 700 + 1000 + 1200 + (eunits - 400) * 15;
            }
            gst = bill * 0.14;
            Console.WriteLine("GST: " +gst);
            tot = bill + gst;
            Console.WriteLine("Total bill: " +tot);
        }
    }
}
