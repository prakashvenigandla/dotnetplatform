﻿using System;


namespace helloworld
{
    class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Mobile { get; set; }
        public string Address { get; set; }
        public string LoyaltyMembership { get; set; }

        public Customer(int id, string name, string email, int mobile, string address, string loyaltyMembership)
        {
            Id = id;
            Name = name;
            Email = email;
            Mobile = mobile;
            Address = address;
            LoyaltyMembership = loyaltyMembership;
        }
        public void Display()
        {
            Console.WriteLine("The customer details: Id:{0} Name:{1} Email:{2} Mobile:{3} Address:{4} Loyalty Membership:{5}", Id, Name, Email, Mobile, Address, LoyaltyMembership);
        }
    }
}
