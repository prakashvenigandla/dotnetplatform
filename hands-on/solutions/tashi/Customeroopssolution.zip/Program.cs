﻿using System;


namespace helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer(001, "Jay", "jay@rediff.com", 98770, "20 Baker Street", "Gold Member");
            c1.Display();
            Customer c2 = new Customer(002, "Ben", "ben@rediff.com", 44770, "82 Park Street", "Silver Member");
            c2.Display();

        }
    }
}
