﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLib;


namespace MathLibClient2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj2 = new Class1();
            Console.WriteLine(obj2.Add(4, 5));

        }
    }
}
