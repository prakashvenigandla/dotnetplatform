﻿using System;


namespace ebill
{
    class Program
    {
        static void Main(string[] args)
        {
            int price = 0;
            int qty = 0;
            int tot = 0;
            string str;
            do
            {
                int ch;
                Console.WriteLine("Your menu is:");
                Console.WriteLine("1.Indian - Rs.1000");
                Console.WriteLine("2.Chinese - Rs.2000");
                Console.WriteLine("3.Italian - Rs.17000");
                Console.WriteLine("4.Thai - Rs.1000");
                Console.WriteLine("5.French - Rs.1200");
                Console.WriteLine("Enter your choice");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            price = 1000;
                            break;

                        }
                    case 2:
                        {
                            price = 2000;
                            break;

                        }
                    case 3:
                        {
                            price = 1700;
                            break;

                        }
                    case 4:
                        {
                            price = 1000;
                            break;

                        }
                    case 5:
                        {
                            price = 1200;
                            break;

                        }
                }
                Console.WriteLine("Enter Quantity: ");
                qty = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Amount: " + price*qty);
                tot = tot + price * qty;
                
                Console.WriteLine("Would you like more? y/n");
                str = Console.ReadLine();

            } while (str == "y");
            Console.WriteLine("Total bill: " + tot);

        }
    }
}
