﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringoperations
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "baker ";
            string str2 = "avenue";
            Console.WriteLine(str1.Length);
            Console.WriteLine(string.Concat(str1, str2));
            Console.WriteLine(string.Compare(str1, str2));
            Console.WriteLine(string.Equals(str1, str2));
            //Console.WriteLine(string.Format(str2, str1));
            Console.WriteLine(string.Intern("abc"));
            char[] a = str2.ToCharArray();
            Console.WriteLine(a);
            Console.WriteLine(str1.Split());
            Console.WriteLine(str1.ToUpper());
            string str3 = str2.Insert(1, "aeiou");
            Console.WriteLine(str3);

        }
    }
}
