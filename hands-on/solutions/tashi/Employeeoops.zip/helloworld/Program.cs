﻿using System;


namespace helloworld
{
    class Program
    {
        public static void Main(string[] args)
        {
            Employee e1 = new Employee("Jay", 40000);
            e1.CalNetPay();
            e1.Display();
            Employee e2 = new Employee("Ben", 60000);
            e2.CalNetPay();
            e2.Display();
        }
    }
}
