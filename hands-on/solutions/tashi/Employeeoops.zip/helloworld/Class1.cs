﻿using System;


namespace helloworld
{
    class Employee
    {
        public string Name { get; set; }
        public int BasicSal { get; set; }
        public decimal HRA { get; set; }
        public decimal DA { get; set; }
        public decimal Tax { get; set; }
        public decimal GrossPay { get; set; }
        public decimal NetSal { get; set; }

        public Employee(string name, int basicSal)
        {
            Name = name;
            BasicSal = basicSal;
        }
    
        public void CalNetPay()
        {
            HRA = (15 * BasicSal)/100;
            DA = (10 * BasicSal) / 100;
            
            GrossPay = BasicSal + HRA + DA;
            Tax = (8 * GrossPay) / 100;
            NetSal = GrossPay - Tax;
        }
        public void Display()
        {
            Console.WriteLine("Name of Employee: {0}",Name );
            Console.WriteLine("Basic Salary: {0}", BasicSal);
            Console.WriteLine("HRA: {0}", HRA);
            Console.WriteLine("DA: {0}", DA);
            Console.WriteLine("Tax: {0}", Tax);
            Console.WriteLine("Gross Pay: {0}", GrossPay);
            Console.WriteLine("Net Salary: {0}", NetSal);
            Console.WriteLine("\n");
        }
    }
}
