﻿struct student
{
    int roll;
    string name;
}