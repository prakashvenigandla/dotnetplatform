﻿using System;

namespace ebill
{
    class Program
    {
        static void Main(string[] args)
        {
            int custid, conu;
            double chg, surchg = 0, gramt, netamt;
            string connm;

            Console.Write("\n\n");
            Console.Write("Calculate Electricity Bill:\n");
            Console.Write("----------------------------");
            Console.Write("\n\n");

            Console.Write("Input Customer ID :");
            custid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Input the name of the customer :");
            connm = Console.ReadLine();
            Console.Write("Input the unit consumed by the customer : ");
            conu = Convert.ToInt32(Console.ReadLine());
            if (conu < 100)
                chg = 5;
            else if (conu >= 101 && conu < 200)
                chg = 7;
            else if (conu >= 201 && conu < 300)
                chg = 10;
            else
                chg = 12;
            gramt = conu * chg;
        
                surchg = gramt * 14 / 100.0;
            netamt = gramt + surchg;
           
            Console.Write("\nElectricity Bill\n");
            Console.Write("Customer IDNO                       :{0}\n", custid);
            Console.Write("Customer Name                       :{0}\n", connm);
            Console.Write("unit Consumed                       :{0}\n", conu);
          
            Console.Write("gst                   :{0}\n", surchg);
            Console.Write("Net Amount Paid By the Customer     :{0}\n", netamt);
        }
    }
}

