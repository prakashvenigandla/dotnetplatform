﻿using System;
public class Demo
{
    public static void Main(string[] args)
    {
        Double Basic_Salary, DA, HRA, Gross_Salary,tax;

        Console.Write("Enter Basic Salary : ");
        Basic_Salary = Convert.ToInt32(Console.ReadLine());

        DA = (Basic_Salary * 10) / 100;
        HRA = (Basic_Salary * 15) / 100;
        tax = (Basic_Salary * 10) / 100;
        Gross_Salary = Basic_Salary + DA + HRA - tax;

        Console.Write("\n\nDearness Allowance 40 % of Basic Salary : " + DA);
        Console.Write("\nHouse Rent 20 % of Basic Salary : " + HRA);
        Console.Write("\nGross Salary : " + Gross_Salary);
        Console.ReadLine();
    }
}