﻿using System;
namespace day_2a 
{
    class Minclass 
    {
        static void Main(string[] args)
        {
            customer details = new customer(123, "shriya", "xyz@abc.com", 1234567890, " road c", "yes");
            details.Display();
        }

    }


}