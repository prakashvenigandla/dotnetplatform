﻿using System;

namespace day_2a
{
    class customer
    {
        public int id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public long mobile { get; set; }
        public string loyaltymembership { get; set; }
        public customer(int id, string name, string email, long mobile,string address, string loyaltymembership)
        {
            this.id = id;
            this.name = name;
            this.email = email;
            this.mobile = mobile;
            this.address = address;
            this.loyaltymembership = loyaltymembership;


        }

        public void Display() 
            {
            Console.WriteLine("customer details");
            Console.WriteLine(" id    : {0}\n" +
                               "name  : {1}\n" +
                               "email  :{2}\n" +
                               "mobile  : {3}\n " +
                               " address : {4}\n" +
                               "loyaltymembership : {5}\n", id, name, email, mobile, address);


            }
        
       
    }
}
