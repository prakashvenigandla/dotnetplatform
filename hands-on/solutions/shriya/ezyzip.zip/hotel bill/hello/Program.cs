﻿using System;

namespace hello
{
    class Program
    {
        public static void Main(string[] args)
        {
            
            //Console.WriteLine("hello world, .NET");
            //Console.ReadLine();
            //int a;
            //int b;
            //int sum;
            //Console.WriteLine("enter");
            //a = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("enter new");
            //b = Convert.ToInt32(Console.ReadLine());
            //sum = a + b;
            //Console.WriteLine("sum is:" + sum);
            //int n, i, m = 0, flag = 0;
            //Console.Write("Enter the Number to check Prime: ");
            //n = int.Parse(Console.ReadLine());
            //m = n / 2;
            //for (i = 2; i <= m; i++)
            //{
            //    if (n % i == 0)
            //    {
            //        Console.Write("Number is not Prime.");
            //        flag = 1;
            //        break;
            //    }
            //}
            //if (flag == 0)
            //    Console.Write("Number is Prime.");
            

            //hotel bill 
            int tbill = 0;
            
            
                Console.WriteLine("1. main course");
                Console.WriteLine("2. rice");
                Console.WriteLine("3. indian bread");
              

                Console.WriteLine("enter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            string str1;
                            do
                            {

                                Console.WriteLine(" main course");
                                Console.WriteLine("10 paneer price 150");
                                Console.WriteLine("11 dal price 100 ");
                                Console.WriteLine("12 kadi price 120");
                                Console.WriteLine("enter your choice");
                                int mc = Convert.ToInt32(Console.ReadLine());

                                switch (mc)
                                {
                                    case 10:
                                        {
                                            Console.WriteLine("1 full plate");
                                            Console.WriteLine("2  half plate ");
                                            int pq = Convert.ToInt32(Console.ReadLine());
                                            if (pq == 1)
                                            {
                                                tbill = tbill + 150;

                                            }
                                            else
                                            {
                                                tbill = tbill + 80;
                                            }

                                        break;

                                        }
                                    case 11:
                                        {
                                            Console.WriteLine("1 full plate");
                                            Console.WriteLine("2  half plate ");
                                            int dq = Convert.ToInt32(Console.ReadLine());
                                            if (dq == 1)
                                            {
                                                tbill = tbill + 100;

                                            }
                                            else
                                            {
                                                tbill = tbill + 60;
                                            }
                                        break;

                                        }
                                    case 12:
                                        {
                                            Console.WriteLine("1 full plate");
                                            Console.WriteLine("2  half plate ");
                                            int kq = Convert.ToInt32(Console.ReadLine());
                                            if (kq == 1)
                                            {
                                                tbill = tbill + 120;

                                            }
                                            else
                                            {
                                                tbill = tbill + 70;
                                            }
                                        break;
                                        }

                            } Console.WriteLine("would you like to select more from maincourse y/n?");
                            str1 = Console.ReadLine();

                        } while (str1 == "y");
                        break;
                    }
                case 2:
                    {
                        string str2;
                        do {
                            Console.WriteLine("2. rice");
                            Console.WriteLine("20. basmati rice price 80");
                            Console.WriteLine("21.  lemon rice price 90");

                            Console.WriteLine("enter your choice");
                            int r = Convert.ToInt32(Console.ReadLine());
                            switch (r)

                            {
                                case 1:
                                    {
                                        Console.WriteLine("1 full plate");
                                        Console.WriteLine("2  half plate ");
                                        int dq = Convert.ToInt32(Console.ReadLine());
                                        if (dq == 1)
                                        {
                                            tbill = tbill + 80;

                                        }
                                        else
                                        {
                                            tbill = tbill + 40;
                                        }
                                        break;

                                    }
                                case 2:
                                    {
                                        Console.WriteLine("1 full plate");
                                        Console.WriteLine("2  half plate ");
                                        int dq = Convert.ToInt32(Console.ReadLine());
                                        if (dq == 1)
                                        {
                                            tbill = tbill + 90;

                                        }
                                        else
                                        {
                                            tbill = tbill + 45;
                                        }
                                        break;
                                    }
                            }
                            Console.WriteLine("would you like to select more from maincourse y/n?");
                            str2 = Console.ReadLine();


                        } while (str2 == "y");
                        break;
                    }
                case 3:
                    {
                        string str3;
                        do
                        {
                            Console.WriteLine(" indian bread");
                            Console.WriteLine("30. roti price 10");
                            Console.WriteLine("31. paratha price 20");
                            Console.WriteLine("enter your choice");
                            int b = Convert.ToInt32(Console.ReadLine());
                            switch (b)
                            {
                                case 1:
                                    {
                                        int a;
                                        Console.WriteLine("number of roti");
                                        a = Convert.ToInt32(Console.ReadLine());
                                        tbill = tbill + (a * 10);
                                        break;
                                    }
                                case 2:
                                    {
                                        int j;
                                        Console.WriteLine("number of roti");
                                        j = Convert.ToInt32(Console.ReadLine());
                                        tbill = tbill + (j * 10);
                                    }
                                    break;

                            }
                            Console.WriteLine("would you like to select more from maincourse y/n?");
                            str3 = Console.ReadLine();



                        } while (str3 == "y");
                        break;
                    }
                }

            Console.WriteLine("sum is:" + tbill);
        }
    }
    
}