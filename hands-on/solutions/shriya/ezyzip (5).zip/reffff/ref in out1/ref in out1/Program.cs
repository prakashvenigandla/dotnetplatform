﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ref_in_out1
{
    class ReferenceTypeExample
    {
        static void Enroll(out Student student)
        {
            
            student = new Student();
            student.Enrolled = false;
        }

        static void Main()
        {
            Student student;

            Enroll(out student);
        }
    }

    public class Student
    {
        public string Name { get; set; }
        public bool Enrolled { get; set; }
    }
}
