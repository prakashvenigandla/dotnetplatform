﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reff_in_out
{
    class ReferenceTypeExample
    {
        static void IncrementExample(ref int num)
        {
            num = num + 1;
        }

        static void Main()
        {
            int num = 1;
            IncrementExample(ref num);
            // num is now 2
        }
    }
}
