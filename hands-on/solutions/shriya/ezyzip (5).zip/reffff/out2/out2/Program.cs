﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace out2
{
    class ReferenceTypeExample
    {
        static void Enroll(in Student student)
        {
           
            student.Enrolled = true;
        }

        static void Main()
        {
            var student = new Student
            {
                Name = "Susan",
                Enrolled = false
            };

            Enroll(student);
        }
    }

    public class Student
    {
        public string Name { get; set; }
        public bool Enrolled { get; set; }
    }
}
