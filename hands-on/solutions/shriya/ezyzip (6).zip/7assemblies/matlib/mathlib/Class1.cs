﻿using System;

namespace mathlib
{
    public class Class1
    {
        public int add(int one, int two) 
        {
            return one + two;
        }

    }
}
