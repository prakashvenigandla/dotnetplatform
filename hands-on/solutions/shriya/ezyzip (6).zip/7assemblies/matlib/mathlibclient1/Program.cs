﻿using System;
using mathlib;
namespace mathlibclient1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 ObJone = new Class1();
            Console.WriteLine(ObJone.add(1, 2));
            Console.ReadLine();

        }
    }
}
