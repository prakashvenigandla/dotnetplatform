﻿using System;

namespace STUDENT
{
    class Program
    {
        static void Main(string[] args)
        {
            Studentdetails student1 = new Studentdetails("Nagesh", 201);
            student1.Display();
            Hosteller hostel = new Hosteller(2058, 10000.25, 10);
            hostel.Display();
            Studentdetails student2 = new Studentdetails("irfan", 116);
            student2.Display();
            Dayscholardetails.Dayscholar dayscholar = new Dayscholardetails.Dayscholar(3456, 10000.25, 5);
            dayscholar.Display();




        }
    }
}
