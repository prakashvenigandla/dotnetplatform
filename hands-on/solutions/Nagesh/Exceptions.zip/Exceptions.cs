﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excetions
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int res = 0;
            Console.WriteLine("Enter a Number :");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Another Number :");
            b = Convert.ToInt32(Console.ReadLine());
            try
            {
                res = a / b;
            }
            catch (DivideByZeroException dbe)
            {
                Console.WriteLine(dbe.Message);
            }
            Console.WriteLine($"res :{ res}");
            try
            {
                int[] arr = new int[5] { 1, 2, 3, 4, 5 };
                Console.WriteLine(arr[6]);
            }
            catch (IndexOutOfRangeException IE)
            {
                Console.WriteLine(IE.Message);
            }


        }
    }
}

 
