﻿using System;

namespace HotelBill
{
    class Program
          
    {
        static void Main(string[] args)
            {
                string str;
            int sum = 0;
                do
                {

                    Console.WriteLine("1. Cofee : Rs 20");
                    Console.WriteLine("2. Tea   : Rs 10");
                    Console.WriteLine("3. Lemonade : Rs 25");
                    Console.WriteLine("4. Water : Rs 5");
                    Console.WriteLine("5. pepsi : Rs 40");
                    Console.WriteLine("Please Enter your choice:");
                    int ch = Convert.ToInt32(Console.ReadLine());
                    
                    switch (ch)
                    {
                        case 1:
                            {
                                sum = sum + 20;
                                Console.WriteLine("Here is your cofee and bill is:" + sum);
                                break;
                            }

                        case 2:
                            {
                                sum = sum + 10;
                                Console.WriteLine("Here is your Tea and bill is:" + sum);
                                break;
                            }

                        case 3:
                            {
                                sum = sum + 25;
                                Console.WriteLine("Here is your Leamonade and bill is:" + sum);
                                break;
                            }
                        case 4:
                            {
                                sum = sum + 5;
                                Console.WriteLine("Here is your Water and bill is:" + sum);
                                break;
                            }
                        case 5:
                            {
                                sum = sum + 40;
                                Console.WriteLine("Here is your Pepsi and bill is:" + sum);
                                break;
                            }

                    }
                    Console.WriteLine("Would you like to continue? press Y for yes and N for No ");
                    str = Console.ReadLine();
                } while (str == "y");
            }
        }
    }


