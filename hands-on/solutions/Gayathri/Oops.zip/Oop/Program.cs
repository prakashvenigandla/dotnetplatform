﻿using System;

namespace Oop
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer cust = new Customer(0001, "Gayathri", "gayathri57@gmail.com",821054777,"Warangal","Loyal Member");
            cust.Display();
        }
    }
}
