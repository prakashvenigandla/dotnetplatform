﻿using System;


namespace HotelBill
{
    class Program
    {
        static void Main(string[] args)
        {
            int n,bill=0;
            string str;
            do
            {
                Console.WriteLine("Menu Card:");
                Console.WriteLine("1.Puri is for 25/-");
                Console.WriteLine("2.Idli is for 20/-");
                Console.WriteLine("3.Dosa is for 25/-");
                Console.WriteLine("4.Poha is for 15/-");
                Console.WriteLine("enter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        {
                            Console.WriteLine("how many would you like to have?");
                            n = Convert.ToInt32(Console.ReadLine());
                            bill = bill + (n * 25);
                            break;
                        }
                    case 2:
                        {

                            Console.WriteLine("how many would you like to have?");
                            n = Convert.ToInt32(Console.ReadLine());
                            bill = bill + (n * 20);
                            break;
                        }
                    case 3:
                        {

                            Console.WriteLine("how many would you like to have?");
                            n = Convert.ToInt32(Console.ReadLine());
                            bill = bill + (n * 25);
                            break;
                        }
                    case 4:
                        {

                            Console.WriteLine("how many would you like to have?");
                            n = Convert.ToInt32(Console.ReadLine());
                            bill = bill + (n * 15);
                            break;
                        }
                }

                Console.WriteLine("would you like to have some more y/n");
                str = Console.ReadLine();
            } while (str == "y");
            if(str=="n")
            {
                Console.WriteLine("Your Bill:"+bill);

            }
        }
    }
}
