﻿using System;

namespace StudentDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Hosteler h1 = new Hosteler(21,80000,179, "Sathwika", "7013426555", "dasusathwika@gmail.com");
            h1.Display();
            Dayscholar d1 = new Dayscholar("Hanamkonda",20000, 179, "Sathwika", "7013426555", "dasusathwika@gmail.com");
            d1.Display();
            Console.ReadLine();
        }
    }
}
