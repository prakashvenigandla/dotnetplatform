﻿using System;

namespace StudentDetails
{
    public class Student
    {
        protected int rollNo;
        protected string name;
        protected string mobileNo;
        protected string email;

        public Student()
        { }
        public Student(int rollNo, string name, string mobileNo, string email)
        {
            this.rollNo = rollNo;
            this.name = name;
            this.mobileNo = mobileNo;
            this.email = email;
        }
        public virtual void Display()
        {
            Console.WriteLine(this.rollNo + "\n" + this.name + "\n" + this.mobileNo + "\n" + this.email);
        }
    }
}
