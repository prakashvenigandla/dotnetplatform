﻿using System;

namespace StudentDetails
{
    public class Hosteler : Student
    {
        int roomNo;
        float hostelFee;
        public Hosteler()
        {
        }
        public Hosteler(int roomNo,float hostelFee, int rollNo,string name,string mobileNo,string email):base(rollNo,name,mobileNo,email)
        {
            this.roomNo = roomNo;
            this.hostelFee = hostelFee;
        }

        public override void Display()
        {
            Console.WriteLine("\nHosteler details: ");
            Console.WriteLine("Name               :"+this.name+ "\n"+
                              "Roll No            :"+this.rollNo + "\n" +
                              "Mobile No.         :"+this.mobileNo + "\n" +
                              "Email Id           :"+this.email + "\n" + 
                              "Hostel fee amount  :"+this.hostelFee + "\n"+
                              "Room No.           :"+this.roomNo);
        }
    }
}
