﻿using System;

namespace StudentDetails
{
    class Dayscholar:Student
    {
        string address;
        float transportFee;
        public Dayscholar()
        { 
        }
        public Dayscholar(string address,float transportFee,int rollNo, string name, string mobileNo, string email) : base(rollNo, name, mobileNo, email)
        {
            this.address = address;
            this.transportFee = transportFee;
        }
        public override void Display()
        {
            Console.WriteLine("\nDay scholar details: ");
            Console.WriteLine("Name                :" + this.name + "\n" +
                              "Roll No             :" + this.rollNo + "\n" +
                              "Mobile No.          :" + this.mobileNo + "\n" +
                              "Email Id            :" + this.email + "\n" +
                              "Transport fee amount:" + this.transportFee + "\n"+
                              "Address             :" + this.address);
        }
    }
}
