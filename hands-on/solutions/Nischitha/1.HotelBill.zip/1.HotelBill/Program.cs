﻿using System;

namespace HotelBill
{
    class Program
    {
        static void Main(string[] args)
        {
            int total_cost = 0;
            int price = 0;
            char ch;
            do
            {
                Console.WriteLine("Menu:");
                Console.WriteLine("1.Puri -----Rs.20 for each");
                Console.WriteLine("2.Dosa------Rs.25 for each");
                Console.WriteLine("3.Idli------Rs.15 for each");
                Console.WriteLine("4.Chapati---Rs.30 for each");
                Console.WriteLine("Please select a dish");
                int a = Convert.ToInt32(Console.ReadLine());
                switch (a)
                {
                    case 1:
                        {
                            price = 20;
                            break;
                        }
                    case 2:
                        {
                            price = 25;
                            break;
                        }
                    case 3:
                        {
                            price = 15;
                            break;
                        }
                    case 4:
                        {
                            price = 30;
                            break;
                        }
                }
                Console.WriteLine("Please Enter Quantity");
                int b = Convert.ToInt32(Console.ReadLine());
                total_cost = total_cost + price * b;
                Console.WriteLine("Would you like to have more?");
                Console.WriteLine("If YES please enter 'y' else enter 'n' ");
                ch = Convert.ToChar(Console.ReadLine());
            } while (ch == 'y');
            Console.WriteLine("Total cost is :" + total_cost);
        }
    }
}
