﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustExceptionDemo
{
    class AccountNotFoundException:Exception
    {
        public AccountNotFoundException()
        {
            Console.WriteLine("Invalid Account Details. Account not found");
        }
    }
}
