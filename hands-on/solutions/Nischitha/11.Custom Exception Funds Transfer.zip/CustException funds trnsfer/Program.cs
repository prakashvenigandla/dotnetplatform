﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Account a1 = new Account("98965896", "Neha", "PYTM91821", "100000");
            Account a2 = new Account("5678", "Kavya",  "Kotak91524", "500000");
            Console.WriteLine("Select a payment system:");
            Console.WriteLine("1.NEFT \n 2.IMPS");
            int s = Convert.ToInt32(Console.ReadLine());
            switch (s)
            {
                case 1:
                    {
                        Console.WriteLine("Secure transaction through NEFT");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Secure transaction through IMPS");
                        break;
                    }
            }
            Console.WriteLine("Enter source Account details:");
            Console.WriteLine("Account Number:");
            string AccNo1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Name:");
            string name1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("IFSC:");
            string ifsc1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter Destination Account Details:");
            Console.WriteLine("Account Number:");
            string AccNo2 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Name:");
            string name2 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("IFSC:");
            string ifsc2 = Convert.ToString(Console.ReadLine());
            if (a1.AccNo == AccNo1 && a1.AccName == name1 && a1.ifsc == ifsc1 && a2.AccNo == AccNo2 && 
                a2.AccName == name2 && a2.ifsc == ifsc2)
            {
                Console.WriteLine("Enter amount in rupees to transfer");
                double x = Convert.ToDouble(Console.ReadLine());
                try
                {
                    a1.AddAmount(a2, x);
                    a1.DisplayBalance();
                }
                catch (ArgumentOutOfRangeException are)
                {
                    Console.WriteLine(are.Message);
                }
            }
            else if (a2.AccNo == AccNo1 && a2.AccName == name1 && a2.ifsc == ifsc1 && a1.AccNo == AccNo2 && 
                a1.AccName == name2 && a1.ifsc == ifsc2)
            {
                Console.WriteLine("Enter amount in rupees to transfer");
                double x = Convert.ToDouble(Console.ReadLine());
                try
                {
                    a2.AddAmount(a1, x);
                    a2.DisplayBalance();
                }
                catch (ArgumentOutOfRangeException are)
                {
                    Console.WriteLine(are.Message);
                }
            }
            else
            {
                throw new AccountNotFoundException();
            }

            Console.ReadLine();
        }
    
    }
}
