﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustExceptionDemo
{
    class Account
    {

        public String AccNo  { get; set; }
        public String AccName { get; set; }
        public string ifsc { get; set; }
        public double Balance { get; set; }
        public Account(string AccNo , string AccName, string ifsc, string Balance)
        {
            this.AccNo = AccNo;
            this.AccName = AccName;
            this.ifsc = ifsc;
            
        }
        public void AddAmount(Account a1,double a)
        {
            if (a > this.Balance)
            {
                throw new ArgumentOutOfRangeException();
            }
            this.Balance = Balance + a;
            Console.WriteLine("transaction successfull,balance is:", Balance);
        }
        public void DisplayBalance()
        {
            Console.WriteLine(Balance);
        }

        




    }
}
