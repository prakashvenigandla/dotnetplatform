﻿using System;
namespace emp
{
    class Employee
    {
            public string Name { get ; set ; }
            public float BasicSalary { get ; set ; }
        public float Hra;
        public float Da;
        public float Tax;
        public float GrossPay;
        public float NetSalary;
        public Employee(string name,float basicsalary)
        {
            Name = name;
            BasicSalary = basicsalary;
        }
        public void CalculateNetPay()
        {
            Hra = 15 * (BasicSalary / 100);
            Da = 10 * (BasicSalary / 100);
            GrossPay = BasicSalary + Hra + Da;
            Tax = 8 * (GrossPay / 100);
            NetSalary = GrossPay - Tax;
        }
        public void Display()
        {
            Console.WriteLine("Employee Details\n");
            Console.WriteLine("Name:{0} BasicSalary:{1} HRA:{2} DA:{3} GrossPay:{4} Tax:{5} NetSalary:{6}", Name, BasicSalary, Hra, Da, GrossPay, Tax, NetSalary);
        }
    }
    class MainClass
    {
        public static void Main(string[] args)
        {
            Employee employee = new Employee("Nischitha", 180000);
            employee.CalculateNetPay();
            employee.Display();
        }
    }
}
