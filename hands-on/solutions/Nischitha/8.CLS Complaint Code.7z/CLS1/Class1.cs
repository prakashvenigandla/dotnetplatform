﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLS1
{
    public class Class1
    {
        public void Calculate(int a)
        {
            Console.WriteLine(a);
        }
    }
}
