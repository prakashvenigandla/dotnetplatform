﻿using System;

namespace ElectricityBill
{
    class Program
    {
        static void Main(string[] args)
        {
            int cost = 0;
            float gst, total_cost;
            Console.WriteLine("Please enter no. of units");
            int a = Convert.ToInt32(Console.ReadLine());
            if(a<=100)
            {
                cost = a * 5;
            }
            else if(a>=101 && a<=200)
            {
                cost = 500 + (a-100)*7;
            }
            else if(a>=201 && a<=300)
            {
                cost = 1200 + (a-200)*10;
            }
            else if(a>=301 && a<=400)
            {
                cost = 2200 +(a-300)*12;
            }
            gst = 14 *cost / 100 ;
            total_cost = gst + cost;
            Console.WriteLine("Amount ")
            Console.WriteLine("GST : " + gst);
            Console.WriteLine("The total electricity bill is: " + total_cost);
            Console.ReadLine();
        }
    }
}
