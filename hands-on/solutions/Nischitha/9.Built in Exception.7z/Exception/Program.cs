﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exception
{
    class Vote
    {
        string Fname, Lname;
        int Age;
        public Vote(string Fname,string Lname,int Age)
        {
            this.Fname = Fname;
            this.Lname = Lname;
            this.Age = Age;
            if (Age < 18)
                throw new ArgumentOutOfRangeException("Age must be greater than 18 to cast your vote.");
            else
                this.Age = Age;
        }
        public string Eligibility()
        {
            string eligible = Fname + " " + Lname + " " + Age.ToString();
            return (eligible);
        }
    }

    class Prg
    {
        static void Main(string[] args)
        {
            try
            {
                Vote obj = new Vote("John", "Ray", 17);
                Console.WriteLine(obj.Eligibility());
            }
            catch (ArgumentOutOfRangeException are)
            {
                Console.WriteLine(are.Message);
            }
            int a, b, res = 0;
            Console.WriteLine("Enter a number");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter another number");
            b = Convert.ToInt32(Console.ReadLine());
            try
            {
                res = a / b;
            }
            catch (DivideByZeroException dbe)
            {
                Console.WriteLine(dbe.Message);
            }
            Console.WriteLine($"res: {res}");
            string s = null;
            try
            {
                Console.WriteLine(s.Length);
            }
            catch(NullReferenceException e)
            {
                Console.WriteLine(e.Message);
            }
            int[] ar = new int[3];
            int i;
            Console.WriteLine("Enter values into array");
            for (i=0;i<ar.Length;i++)
            {
                Console.ReadLine();
            }
            try
            {
                Console.WriteLine(ar[4]);
            }
            catch(IndexOutOfRangeException ioe)
            {
                Console.WriteLine(ioe.Message);
            }
            Console.WriteLine("Argument Null Exception");
        }
    }
}
