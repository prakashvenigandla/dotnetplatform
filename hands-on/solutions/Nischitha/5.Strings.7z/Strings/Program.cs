﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Strings
{
    class Program
    {
        public static void Main(String[] args)
        {
            string fname = "John";
            string lname = "Paul";
            string str1 = "Hello";
            string str2 = "World";
            Console.WriteLine(String.Concat(fname, lname));
            Console.WriteLine(String.Compare(str1, str2));
            Console.WriteLine(String.CompareOrdinal(str1, str2));
            Console.WriteLine(str1.CompareTo(str2));
            Console.WriteLine(str1.Equals(str2));
        }
    }
}
