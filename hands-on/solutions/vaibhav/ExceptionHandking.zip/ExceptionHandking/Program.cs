﻿using System;

namespace ExceptionHandling
{
    class Program
    {
        public static void Main(string[] args)
        {
            int a;
            int b;
            int res = 0;
            int c = 0;
            Console.WriteLine("enter a no");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter another no");
            
            try
            {
                b = Convert.ToInt32(Console.ReadLine());
                res = a / b;
                c = a * b;
            }
            catch (DivideByZeroException dbe)
            {
                Console.WriteLine(dbe.Message);
            }

            catch (FormatException fe)
            {
                Console.WriteLine(fe.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"res: {res}");
            Console.WriteLine($"c: {c}");

        }
    }
}
