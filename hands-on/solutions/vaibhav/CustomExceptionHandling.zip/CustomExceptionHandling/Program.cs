﻿using System;

namespace CustomExceptionHandling
{
    class Program
    {
         public static void Main(string[] args)
        {
            CustomerAcc customeracc1 = new CustomerAcc();
            customeracc1.CurrentPoints = 10000;
            int points;
            Console.WriteLine("Enter number of points you want to sell");
            points = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Now you can buy things upto:"+ points);
            Console.WriteLine("list of items under points \n 500-2000- Any Toy,Beauty product\n2100-5000-Electric items,chairs\n6000-10000-Mobile Phones,Laptop\n11000-50000-Automobiles");

            customeracc1.Sell(points);
                


        }
    }
}
