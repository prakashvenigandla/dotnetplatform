﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomExceptionHandling
{
    public class InsufficientPointsException:ApplicationException
    {
        public InsufficientPointsException(string message):base(message)
        {

        }
    }
}
