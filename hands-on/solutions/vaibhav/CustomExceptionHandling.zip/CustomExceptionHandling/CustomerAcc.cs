﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomExceptionHandling
{
    public class CustomerAcc
    {
        public CustomerAcc()
        {
        }
        public int CurrentPoints { get; set; }
        public void DepositedPoints ( int points )
        {
          CurrentPoints += points;
            Console.WriteLine($"Points added your current points are:{CurrentPoints}");
        }
        public void Sell(int points)
        {
            try
            {
                if (points > CurrentPoints)
                {
                    throw new InsufficientPointsException(string.Format("Insufficient points, please enter less points thant current points." + "your current points are :{0}", CurrentPoints));
                }

                CurrentPoints -= points;
            }
            catch(InsufficientPointsException ipe)
            {
                Console.WriteLine(ipe.Message);
            }
            finally
            {

            }
            }
        }
    }
    


