﻿using System;

namespace OOPS4
{
    class Program
    {
        static void Main(string[] args)
        {
            employee emp = new employee("Vaibhav", 50000);
            emp.CalculateNetPay();
            emp.Display();
        }
    }
}
