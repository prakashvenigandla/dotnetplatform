﻿using System;
namespace OOPS4
{
    class employee
    {
        readonly String employee_name;
        private readonly double basicSalary;
        private double hra;
        private double da;
        private double tax;
        private double grossPay;
        private double netPay;

        public employee(String name, double bs)
        {
            this.employee_name = name;
            this.basicSalary = bs;
        }
        public void CalculateNetPay()
        {
            hra = 0.15 * basicSalary;
            da = 0.10 * basicSalary;
            grossPay = basicSalary + hra + da;
            tax = 0.08 * grossPay;
            netPay = grossPay - tax;
        }
        public void Display()
        {
            Console.WriteLine("Employee Name is:" + employee_name);
            Console.WriteLine("Basic Salary:" + basicSalary);
            Console.WriteLine("House Rent Allowance:" + hra);
            Console.WriteLine("Dearness Allowance:" + da);
            Console.WriteLine("Gross Pay is:" + grossPay);
            Console.WriteLine("Tax is:" + tax);
            Console.WriteLine("Net Salary of Employee is:" + netPay);
        }
    }
}
