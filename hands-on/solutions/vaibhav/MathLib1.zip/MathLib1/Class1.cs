﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLib1
{
    public class Class1
    {
        public int Mul(int one,int two)
        {
            return one * two;
        }
        public int Add(int three,int four)
        {
            return three + four;
        }
    }
}
