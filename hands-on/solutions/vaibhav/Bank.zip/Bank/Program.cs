﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    class Program
    {
        static void Main(string[] args)
        {
            Acc a1 = new Acc("9650", "Vaibhav", "Savings", 200000, "PUNB2345", "Dwarka");
            Acc a2 = new Acc("37352582", "Vardaan", "Savings", 100000, "HDFC23456", "Janakpuri");
            Console.WriteLine("Select a payment system:");
            Console.WriteLine("1.NEFT \n 2.RTGS");
            int s = Convert.ToInt32(Console.ReadLine());
            switch (s)
            {
                case 1:
                    {
                        Console.WriteLine("Securely transferring through NEFT");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Securely transferring through RTGS");
                        break;
                    }
            }
            Console.WriteLine("Enter source Account details:");
            Console.WriteLine("Account Number:");
            string AccNo1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Name:");
            string name1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("IFSC:");
            string ifsc1 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Enter Destination Account Details:");
            Console.WriteLine("Account Number:");
            string AccNo2 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Name:");
            string name2 = Convert.ToString(Console.ReadLine());
            Console.WriteLine("IFSC:");
            string ifsc2 = Convert.ToString(Console.ReadLine());
            if (a1.accountNo == AccNo1 && a1.name == name1 && a1.ifsc == ifsc1 && a2.accountNo == AccNo2 && a2.name == name2 && a2.ifsc == ifsc2)
            {
                Console.WriteLine("Enter amount in rupees to transfer");
                double a = Convert.ToDouble(Console.ReadLine());
                try
                {
                    a1.TransferAmount(a2, a);
                    a1.DisplayBalance();
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Insufficient Balance....");
                }
            }
            else if (a2.accountNo == AccNo1 && a2.name == name1 && a2.ifsc == ifsc1 && a1.accountNo == AccNo2 && a1.name == name2 && a1.ifsc == ifsc2)
            {
                Console.WriteLine("Enter amount in rupees to transfer");
                double a = Convert.ToDouble(Console.ReadLine());
                try
                {
                    a2.TransferAmount(a1, a);
                    a2.DisplayBalance();
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Insufficient balance");
                }
            }
            else
            {
                throw new AccountNotFoundException();
            }

            Console.ReadLine();
        }
    }
}