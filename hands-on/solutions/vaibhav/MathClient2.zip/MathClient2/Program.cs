﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLib1;
namespace MathClient2
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 objone = new Class1();
            objone.Mul(8, 3);
            Console.WriteLine(objone.Mul(8, 3));
            Class1 objtwo = new Class1();
            objtwo.Add(6, 5);
            Console.WriteLine(objtwo.Add(6, 5));
        }
    }
}
