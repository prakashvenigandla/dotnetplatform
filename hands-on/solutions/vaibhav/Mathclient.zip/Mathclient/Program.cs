﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLib1;
//using MathLibVB;
namespace Mathclient
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 objone = new Class1();
            objone.Mul(2, 3);
            Console.WriteLine(objone.Mul(2, 3));
            Class1 objtwo = new Class1();
            objtwo.Add(4, 5);
            Console.WriteLine(objtwo.Add(4, 5));
            // Class2 obj1 = new Class2();
            //obj1.Add(5, 3);
        }

    }
}
