﻿using System;

namespace stringimplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "vaibhav";
            string str2 = "vardaan";

            if (String.Compare(str1, str2) == 0)
            {
                Console.WriteLine(str1 + " and " + str2 + " are same.");
            }
            else
            {
                Console.WriteLine(str1 + " and " + str2 + " are not not same .");
            }

            string[] starray = new string[]{"vaibhav",
            "12345678",
            "Male",
            "Amity",
            "Gurugram"};

            string str = String.Join("Btech computer science", starray);
            Console.WriteLine(str);
        }

    }
}
