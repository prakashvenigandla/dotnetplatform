﻿using System;
using System.Collections.Generic;
using System.Text;

namespace student
{
   public class Hosteller: Studentdetails 
    {
        public Hosteller()
        { 
        }
        public Hosteller(int mobile,double fee,int no_activities)
        {
           
            this.mobile = mobile;
            this.fee = fee;
            this.no_activities = no_activities;
        }
        public override void Display()
        {
            fee = fee + (fee * 2);
            Console.WriteLine("Hostller fees is :" + fee);
            Console.WriteLine("Hosteller mobile no is :" + mobile);
            Console.WriteLine("No of activities in total are: " + no_activities);
        }
    }
}
