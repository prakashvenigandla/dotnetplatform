﻿using System;

namespace student
{
    class Program
    {
        static void Main(string[] args)
        {
            Studentdetails student1 = new Studentdetails("Vaibhav", 5258);
            student1.Display();
            Hosteller hostel = new Hosteller( 1234,10000.25,10);
            hostel.Display();
            Studentdetails student2 = new Studentdetails("Rahul", 9650);
            student2.Display();
            Dayscholar dayscholar = new Dayscholar(3456, 10000.25, 5);
            dayscholar.Display();




        }
    }
}
