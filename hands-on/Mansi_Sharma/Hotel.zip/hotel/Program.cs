﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hotel
{
    class Program
    {
        static void Main(string[] args)
        {
            int quantity, choice,totalbill=0;
            char order_more = 'n';
            int coffee_price = 20;
            int tea_price = 10;
            int juice_price = 40;
            int greentea_price = 50;

          do
            {
                Console.WriteLine("Here is the menu: ");
                Console.WriteLine("1-Coffee");
                Console.WriteLine("2-Tea");
                Console.WriteLine("3-Juice");
                Console.WriteLine("4-Green Tea");
                Console.WriteLine("Input your choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Quantity you want:");
                quantity = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Price of coffee is 20 rupee. ");
                        totalbill = quantity * coffee_price;
                        Console.WriteLine("Your bill is :" + totalbill);
                        break;
                    case 2:
                        Console.WriteLine("Price of tea is 10 rupee. ");
                        totalbill = quantity * tea_price;
                        Console.WriteLine("Your bill is :" + totalbill);
                        break;
                    case 3:
                        Console.WriteLine("Price of juice is 40 rupee. ");
                        totalbill = quantity * juice_price;
                        Console.WriteLine("Your bill is :" + totalbill);
                        break;
                    case 4:
                        Console.WriteLine("Price of green tea is 50 rupee. ");
                        totalbill = quantity * greentea_price;
                        Console.WriteLine("Your bill is :" + totalbill);
                        break;
                    default:
                        Console.WriteLine("Not listed in the menu.");
                        break;
                }
                Console.WriteLine("Want anything else? (Y/N) ");
                order_more= Convert.ToChar(Console.ReadLine());

            } while (order_more == 'Y');

            Console.WriteLine("Total amount is : {0}", totalbill);
        }
    }
}
