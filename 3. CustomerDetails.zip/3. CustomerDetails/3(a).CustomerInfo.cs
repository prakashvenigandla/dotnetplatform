﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomerDetails
{
    class Customer
    {
        private int id;
        private string fname;
        private string lname;
        private string mail;
        private string mobile;
        private string address;
        private string l_membership;
        public int Id { get; set; }
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Mail { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string L_Membership { get; set; }

        public Customer()
        {
            
        }
        public Customer(int Id, string Fname, string Lname, string Mail, string Mobile, string Address, string L_Membership)

        {
            id = Id;
            fname = Fname;
            lname = Lname;
            mail = Mail;
            mobile = Mobile;
            address = Address;
            l_membership = L_Membership;
        }
        
        
        public void Display(int n,int Id, string Fname, string Lname, string Mail, string Mobile, string Address, string L_Membership)
        {
            Console.WriteLine(" Details of Customer:- "+(n+1));
            Console.WriteLine("Id:- "+ Id + "  First Name:- " +Fname +"  Last Name:-  "+Lname+ "  Email:- " +Mail+ "  mobile_Number:- "+Mobile+" Address:- "+Address+" Loyalty_Membership:- "+ L_Membership) ;
        }  

            }
}
