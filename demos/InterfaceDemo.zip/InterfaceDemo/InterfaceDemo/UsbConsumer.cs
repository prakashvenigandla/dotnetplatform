﻿using System;
namespace InterfaceDemo
{
    public class UsbConsumer
    {
        public UsbConsumer()
        {
        }
        public void UseUsbService()
        {
            IUsbPortService usbPortService = new Kingston();
            usbPortService.UsbService();
            usbPortService = new Samsung();
            usbPortService.UsbService();
        }
    }
}
