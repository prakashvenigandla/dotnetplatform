﻿using System;
namespace InterfaceDemo
{
    public class Samsung:IUsbPortService
    {
        public Samsung()
        {
        }

        public void UsbService()
        {
            Console.WriteLine("Using Samsung");
        }
    }
}
