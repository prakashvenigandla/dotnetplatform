﻿using System;

namespace InterfaceDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            UsbConsumer usbConsumer = new UsbConsumer();
            usbConsumer.UseUsbService();
        }
    }
}
