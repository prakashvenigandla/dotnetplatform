﻿using System;
namespace InterfaceDemo
{
    public class Kingston:IUsbPortService
    {
        public Kingston()
        {
        }

       public void UsbService()
        {
            Console.WriteLine("Using Kingston");
        }
    }
}
