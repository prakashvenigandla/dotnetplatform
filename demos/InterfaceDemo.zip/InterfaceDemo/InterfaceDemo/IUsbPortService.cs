﻿using System;
namespace InterfaceDemo
{
    public interface IUsbPortService
    {
        void UsbService();//declaration
    }
}
