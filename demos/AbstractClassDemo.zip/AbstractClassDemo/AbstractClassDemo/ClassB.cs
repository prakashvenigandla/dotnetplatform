﻿using System;
namespace AbstractClassDemo
{
    public class ClassB
    {
        public ClassB()
        {
        }
    }
}
