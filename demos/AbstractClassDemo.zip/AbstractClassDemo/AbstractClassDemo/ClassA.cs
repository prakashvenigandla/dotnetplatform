﻿using System;
namespace AbstractClassDemo
{
    public abstract class ClassA
    {
        public ClassA()
        {
        }
        public void Service1()//implemented
        {
            Console.WriteLine("Service 1");
        }
        //public abstract void Service2();//not implemented
        
    }
}
