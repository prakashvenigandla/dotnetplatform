﻿using System;
namespace InheritanceDemo
{
    public class Circle:Shape
    {
        public Circle():base()//
        {
        }
        public Circle(string color)//
        {
            this.color = color;//
        }
        public Circle(string circleColor,string shapeColor):base(shapeColor)//constructor chaining
        {
            this.color = circleColor;
        }
        public new void Draw()
        {
            Console.WriteLine("Drawing circle in {0}",color);
            Console.WriteLine("Shape color:{0}",base.color);
        }
    }
}
