﻿using System;
namespace InheritanceDemo
{
    public interface IShape
    {
    }
}
