﻿using System;
namespace InheritanceDemo
{
    public class Rectangle:Shape
    {
        public Rectangle()
        {
        }
    }
}
