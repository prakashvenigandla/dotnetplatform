﻿using System;
namespace InheritanceDemo
{
    public class Shape
    {
        protected string color;//instance field
        public Shape(string color)//
        {
            this.color = color;
        }
        public Shape()
        {

        }
        public void Draw()
        {
            Console.WriteLine("Drawing shape in {0}",color);
        }
    }
}
