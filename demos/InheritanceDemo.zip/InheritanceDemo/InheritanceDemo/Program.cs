﻿using System;

namespace InheritanceDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //Console.WriteLine("Fun with Shapes!");
            //Shape shape = new Shape("red");
            //shape.Draw();
            //Circle circle = new Circle();
            //circle.Draw();


            Shape shape;
            shape = new Circle("green", "yellow");
            shape.Draw();
            shape = new Shape("red");
            shape.Draw();
        }
    }
}
