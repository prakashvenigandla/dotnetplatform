﻿using System;
namespace InheritanceDemo
{
    public class Square:Shape
    {
        public Square()
        {
        }
    }
}
