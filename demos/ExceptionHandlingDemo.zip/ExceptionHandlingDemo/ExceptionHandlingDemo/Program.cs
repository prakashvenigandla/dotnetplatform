﻿using System;

namespace ExceptionHandlingDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            int a;
            int b;
            int res=0;
            Console.WriteLine("enter a no");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter another no");
            b = Convert.ToInt32(Console.ReadLine());
            try
            {
                res = a / b;
            }
            catch(DivideByZeroException dbe)
            {
                Console.WriteLine(dbe.Message);
            }
            Console.WriteLine($"res: {res}");
        }
    }
}
