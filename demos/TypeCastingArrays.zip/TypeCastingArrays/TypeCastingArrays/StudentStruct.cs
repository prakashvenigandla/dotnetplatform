﻿using System;
namespace TypeCastingArrays
{
    public struct StudentStruct
    {
        public int rollNo;
        public string name;
    }
}
