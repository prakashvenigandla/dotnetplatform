﻿using System;
namespace TypeCastingArrays
{
    public class StudentClass
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
    }
}
