﻿using System;

namespace TypeCastingArrays
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Object[] objects;
            string[] names = { "abc", "xyz" };//strings(reference type)
            objects = names;
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }

            int[] scores = { 1, 2, 3 };//int array(value type)
            objects = Array.ConvertAll<int, object>(scores, (x) => (object)x);
            foreach (var score in scores)
            {
                Console.WriteLine(score);
            }

            int a = 10;
            object obj = (object)a;
            Console.WriteLine(obj);//boxing i.e. from value type to reference type

            int b = (int)obj;
            Console.WriteLine(b);//unboxing i.e. from reference  type to value type
        }
    }
}
