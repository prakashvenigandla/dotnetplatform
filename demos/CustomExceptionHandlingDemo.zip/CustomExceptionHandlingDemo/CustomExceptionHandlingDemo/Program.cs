﻿using System;

namespace CustomExceptionHandlingDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Account account1 = new Account();
            account1.Balance = 5000;
            int amount;
            Console.WriteLine("Please enter the amount you want to withdraw");
            amount = Convert.ToInt32(Console.ReadLine());
            account1.Withdraw(amount);

        }
    }
}
