﻿using System;
namespace CustomExceptionHandlingDemo
{
    public class Account
    {
        public Account()
        {
        }
        public int Balance { get; set; }
        public void Deposit(int amount)
        {
            Balance += amount;
            Console.WriteLine($"Trascation successful, your current balance:{Balance}");
        }
        public void Withdraw(int amount)
        {
            try
            {
                if(amount>Balance)
                {

                    throw new InsufficientFundsException(
                        string.Format("Insufficent funds, please enter lesser amount than balance. " +
                        "Your current balance:{0}",Balance));
                }

                Balance -= amount;
            }
            catch(InsufficientFundsException ife)
            {
                Console.WriteLine(ife.Message);
            }
        }
    }
}
