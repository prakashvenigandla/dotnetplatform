﻿using System;
namespace CustomExceptionHandlingDemo
{
    public class InsufficientFundsException:ApplicationException
    {
        public InsufficientFundsException(string message):base(message)
        {
        }
    }
}
