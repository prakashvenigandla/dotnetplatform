﻿using System;

namespace OopsConcepts
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Employee employee = new Employee(1234, "raj", "kumar", "manager", "male", "raj@google.com");//actual parameters
            employee.Display();
            Console.WriteLine(Employee.CompanyName);//class member

            Employee employee1 = new Employee();
            employee1.Id = 2345;
            employee1.FirstName = "abc";
            employee1.LastName = "xyz";
            employee1.Designation = "clerk";
            employee1.Gender = "female";
            employee1.Email = "abcxyz@gmail.com";
            employee1.Display();


            Employee employee2 = new Employee(1234, "raj", "kumar", "male", "raj@google.com");
            employee.Display();
            //employee.number2 = 100;
            Console.WriteLine(Employee.number);
            

            string str1 = "hello";
            
            string str2 = "hi";
            string.Compare(str1, str2);
            
        }
    }
}
