﻿using System;
class Employee//PascalCase
{
    public static string CompanyName = "Abc Inc";
    public const int number=100;
    public readonly int number2;
    ////Fields
    //private int id;//camelCase
    //private string firstName;
    ////private string lastName;
    //private string designation;
    //private string gender;
    //private string email;

    ////Properties
    //public int Id
    //{
    //    get { return id; }
    //    set { id = value; }
    //}

    //public string FirstName {
    //    get => firstName; set => firstName = value;
    //}

    //auto implemented property
    //public int Id { get; set; }//is same as
    private int id;//instance variable
    public int Id
    {
        get { return id; }
        set { id = value; }
    }
    public string FirstName { get; set; }//auto implemented property
    public string LastName { get; set; }
    public string Designation { get; set; }
    public string Gender { get; set; }
    public string Email { get; set; }


    //Constructor
    public Employee(int id,string firstName,string lastName,string designation,string gender,string email)//formal parameters
    {
        int temp=1;//
        this.id = temp;
        this.id = id;//instance member
        //this.Id = id;
        this.FirstName = firstName;
        this.LastName = lastName;
        Designation = designation;
        Gender = gender;
        Email = email;
    }
    public Employee()//parameterless constructor
    {

    }
    public Employee(int id,string firstName,string lastName,string gender,string email)
    {
        this.id = id;
        FirstName = firstName;
        LastName = lastName;
        Gender = gender;
        Email = email;
        
    }

    public Employee(int number)
    {
        this.number2 = number;
    }

    //Methods
    public void Display()//PascalCase
    {
        Console.WriteLine("Employee Info:");
        Console.WriteLine("Id:{0} FirstName:{1} LastName:{2} Designation:{3} Gender:{4} Email:{5}",
            this.id,FirstName,LastName,Designation,Gender,Email);
    }

    public int CalculateSalary()
    {
        return 0;
    }

    public void SwipeIn()
    {

    }
    public void SwipeOut()
    {

    }

}