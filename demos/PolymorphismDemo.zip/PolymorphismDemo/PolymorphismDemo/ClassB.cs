﻿using System;
namespace PolymorphismDemo
{
    public class ClassB:ClassA
    {
        public ClassB()
        {
        }
        public override void Display(int a)
        {
            Console.WriteLine("Class B {0}",a);
        }
    }
}
