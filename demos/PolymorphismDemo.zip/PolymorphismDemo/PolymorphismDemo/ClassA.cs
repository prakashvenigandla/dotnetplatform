﻿using System;
namespace PolymorphismDemo
{
    public class ClassA
    {
        public ClassA()
        {
        }
        public virtual void Display(int a)
        {
            Console.WriteLine("Class A {0}",a);
        }
    }
}
