﻿using System;

namespace PolymorphismDemo
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            //MathOperations mathOperations = new MathOperations();
            //Console.WriteLine( MathOperations.Add(1, 2));
            //Console.WriteLine( MathOperations.Add(1, 2, 3));
            //Console.WriteLine(MathOperations.Add(1.5f, 2.2f));
            //Console.WriteLine();

            ClassA classA = new ClassA();//run time polymorphism
            classA.Display(1);
            classA = new ClassB();//run time
            classA.Display(2);

            
        }
    }
}
