﻿using System;
using System.Collections.Generic;
using System.Text;

namespace students_hostel_dayscholar
{
    class Student


    {
        public string firstname;
        public string lastname;
        public float Fee;

        public Student () 
        { }

        public Student(string firstName, string lastName, float Fee)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.FEE = Fee;
        }

        public void Display()
        {
            Console.WriteLine(" name:" + FirstName + LastName);
            Console.WriteLine("fees is: "+ Fee);
            Console.ReadLine();

        }




        public string FirstName { get; set; }
        public string LastName { get; set; }
        public float FEE { get; set; }
    }
}

