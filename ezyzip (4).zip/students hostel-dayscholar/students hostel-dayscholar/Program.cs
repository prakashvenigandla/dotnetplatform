﻿using System;

namespace students_hostel_dayscholar
{
    class Program
    {
        static void Main(string[] args)
        {
            Student t1 = new Student("shriya", "khare", 0.04f);
            t1.Display();


            hostel h1 = new hostel("shriya ", "khare", 0.04f);
            h1.Display();

            dayscholar d1 = new dayscholar("xyz ", "abc", 0.03f);
            d1.Display();



        }
    }
}
