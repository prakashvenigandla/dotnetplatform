﻿using System;
using System.Collections.Generic;
using System.Text;

namespace students_hostel_dayscholar
{
    class dayscholar:Student { 

		public dayscholar (string fristname, string lastname, float Fee) { 
    
		
			this.FirstName = FirstName;
			this.LastName = LastName;
			this.FEE = Fee;
		}

		public virtual void Display()
        {
			Console.WriteLine("name:" + firstname + lastname);
			Console.WriteLine("fees for day scholar" + Fee);
		}
        
	}
}
